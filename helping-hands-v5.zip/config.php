<?php
declare(strict_types=1);
if (session_status() !== PHP_SESSION_ACTIVE) session_start();

const DB_HOST = 'sql112.infinityfree.com';
const DB_NAME = 'if0_42966243_helping';
const DB_USER = 'if0_42966243';
const DB_PASS = 'nYDsSgnwpXFb';

try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER,
        DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES => false]
    );
} catch (PDOException $e) {
    http_response_code(500);
    die('<!doctype html><html><head><meta charset="utf-8"><title>Database Setup Required</title><link rel="stylesheet" href="common.css?v=5"></head><body><main class="setup-error"><div class="panel"><div class="brand-mark">HH</div><h1>Helping Hands needs its database</h1><p>Apache and PHP are running, but MySQL is not connected to <strong>' . DB_NAME . '</strong>.</p><ol><li>Open your hosting control panel and confirm the MySQL database exists.</li><li>Check the four database values at the top of <strong>config.php</strong>.</li><li>Import <strong>schema.sql</strong> into your InfinityFree database, then refresh this page.</li></ol><p class="muted">Do not use localhost/root credentials on InfinityFree. Use the database hostname, database name, username and password shown by your hosting account.</p></div></main></body></html>');
}

function h(mixed $value): string { return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8'); }
function redirect(string $url): never { header('Location: ' . $url); exit; }
function logged_in(): bool { return isset($_SESSION['user_id']) && (int)$_SESSION['user_id'] > 0; }
function require_login(string $next = ''): void { if (!logged_in()) redirect('login.php' . ($next !== '' ? '?next=' . urlencode($next) : '')); }
function user(): ?array { global $pdo; if (!logged_in()) return null; $stmt=$pdo->prepare('SELECT * FROM users WHERE id=?'); $stmt->execute([(int)$_SESSION['user_id']]); return $stmt->fetch() ?: null; }
function csrf_token(): string { if (empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(32)); return $_SESSION['csrf']; }
function verify_csrf(): void { if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) { http_response_code(419); exit('Invalid form token. Please refresh the page and try again.'); } }
function flash(string $type, string $message): void { $_SESSION['flash']=['type'=>$type,'message'=>$message]; }
function get_flash(): ?array { $f=$_SESSION['flash']??null; unset($_SESSION['flash']); return $f; }

require_once __DIR__ . '/lib.php';
