<?php
require __DIR__ . "/config.php";
$admin = require_admin();
$tab = $_GET["tab"] ?? "overview";
$tabs = ["overview" => ["Overview", "fa-chart-simple"], "verification" => ["Verification", "fa-shield-heart"], "users" => ["Users", "fa-users"],
         "requests" => ["Requests", "fa-hand-holding-heart"], "messages" => ["Messages", "fa-envelope"], "emails" => ["Email & SMS log", "fa-paper-plane"]];
if (!isset($tabs[$tab])) $tab = "overview";

/* ---------------- actions ---------------- */
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    verify_csrf();
    $a = $_POST["action"] ?? "";
    $back = "admin.php?tab=" . urlencode($_POST["tab"] ?? $tab);

    if ($a === "verify") {
        $uid = post_id("uid");
        $ok = ($_POST["decision"] ?? "") === "approve";
        $note = trim($_POST["note"] ?? "");
        if (!$ok && $note === "") { flash("error", "Please give a short reason when rejecting, so the volunteer knows what to fix."); redirect($back); }
        $q = $pdo->prepare("SELECT id_document FROM volunteers WHERE user_id=? AND verification_status='Pending'");
        $q->execute([$uid]);
        $row = $q->fetch();
        if ($row) {
            if (!empty($row["id_document"])) @unlink(__DIR__ . "/uploads/ids/" . basename($row["id_document"]));   // ID is deleted once decided
            $pdo->prepare("UPDATE volunteers SET verification_status=?, id_document=NULL, verification_note=?, verified_at=?, verified_by=? WHERE user_id=?")
                ->execute([$ok ? "Verified" : "Rejected", $ok ? null : mb_substr($note, 0, 255), $ok ? date("Y-m-d H:i:s") : null, $admin["id"], $uid]);
            notify($uid, "verification", $ok ? "You are now a verified volunteer" : "Verification needs another look",
                $ok ? "Your ID and references were approved. You can now accept tasks in the Task Centre." : "We could not approve your verification: " . $note . " You can submit again.",
                $ok ? "tasks.php" : "verify.php");
            flash("success", $ok ? "Volunteer approved." : "Volunteer rejected and notified.");
        } else flash("error", "That submission is no longer pending.");
        redirect($back);
    }
    if ($a === "toggle_admin") {
        $uid = post_id("uid");
        if ($uid === (int)$admin["id"]) flash("error", "You cannot change your own administrator access.");
        else { $pdo->prepare("UPDATE users SET is_admin = 1 - is_admin WHERE id=?")->execute([$uid]); flash("success", "Administrator access updated."); }
        redirect($back);
    }
    if ($a === "volunteer_status") {
        $pdo->prepare("UPDATE volunteers SET status = IF(status='Active','Paused','Active') WHERE user_id=?")->execute([post_id("uid")]);
        flash("success", "Volunteer status updated."); redirect($back);
    }
    if ($a === "cancel_request") {
        $rid = post_id("rid");
        $q = $pdo->prepare("SELECT * FROM requests WHERE id=? AND status IN ('Pending','Accepted')");
        $q->execute([$rid]);
        if ($r = $q->fetch()) {
            $pdo->prepare("UPDATE requests SET status='Cancelled', cancelled_at=NOW(), updated_at=NOW(), cancel_reason='Cancelled by an administrator' WHERE id=?")->execute([$rid]);
            notify((int)$r["user_id"], "cancelled", "Your request was cancelled by our team", "A coordinator cancelled your " . $r["category"] . " request. Please contact us if you have questions.", "contact.php");
            if ($r["volunteer_id"]) notify((int)$r["volunteer_id"], "cancelled", "A task you accepted was cancelled", "A coordinator cancelled the " . $r["category"] . " request for " . $r["preferred_date"] . ".", "tasks.php");
            flash("success", "Request cancelled and both people notified.");
        } else flash("error", "That request cannot be cancelled.");
        redirect($back);
    }
    if ($a === "message_status") {
        $st = $_POST["status"] ?? "";
        if (in_array($st, ["New", "Read", "Resolved"], true)) $pdo->prepare("UPDATE contact_messages SET status=? WHERE id=?")->execute([$st, post_id("mid")]);
        flash("success", "Message updated."); redirect($back);
    }
    redirect($back);
}

$count = fn(string $sql): int => (int)$pdo->query($sql)->fetchColumn();
$pendingVerif = $count("SELECT COUNT(*) FROM volunteers WHERE verification_status='Pending'");
$newMsgs = $count("SELECT COUNT(*) FROM contact_messages WHERE status='New'");

page_start("Administrator Dashboard", [], "admin");
?>
<div class="container page-top">
  <span class="eyebrow">STAFF ONLY</span>
  <h1>Administrator dashboard</h1>
  <p>Review volunteers, users, requests and messages without opening phpMyAdmin.</p>
</div>
<section class="section" style="padding-top:12px">
<div class="container">
  <nav class="admin-tabs" aria-label="Dashboard sections">
    <?php foreach ($tabs as $k => [$label, $icon]): ?>
      <a href="admin.php?tab=<?php echo h($k); ?>"<?php echo $k === $tab ? ' class="on" aria-current="page"' : ""; ?>><i class="fa-solid <?php echo $icon; ?>" aria-hidden="true"></i> <?php echo h($label); ?>
        <?php if ($k === "verification" && $pendingVerif): ?><span class="count"><?php echo $pendingVerif; ?></span><?php endif; ?>
        <?php if ($k === "messages" && $newMsgs): ?><span class="count"><?php echo $newMsgs; ?></span><?php endif; ?></a>
    <?php endforeach; ?>
  </nav>

<?php if ($tab === "overview"):
  $k = [
    ["Members", $count("SELECT COUNT(*) FROM users")],
    ["Volunteers", $count("SELECT COUNT(*) FROM volunteers")],
    ["Verified volunteers", $count("SELECT COUNT(*) FROM volunteers WHERE verification_status='Verified'")],
    ["Awaiting verification", $pendingVerif],
    ["Pending requests", $count("SELECT COUNT(*) FROM requests WHERE status='Pending'")],
    ["Accepted", $count("SELECT COUNT(*) FROM requests WHERE status='Accepted'")],
    ["Completed", $count("SELECT COUNT(*) FROM requests WHERE status='Completed'")],
    ["Cancelled", $count("SELECT COUNT(*) FROM requests WHERE status='Cancelled'")],
    ["New messages", $newMsgs],
    ["Average rating", ($r = $pdo->query("SELECT ROUND(AVG(stars),1) FROM ratings")->fetchColumn()) ? $r . " / 5" : "n/a"],
  ]; ?>
  <div class="kpi-grid"><?php foreach ($k as [$l, $v]): ?><div class="kpi"><strong><?php echo h($v); ?></strong><small><?php echo h($l); ?></small></div><?php endforeach; ?></div>
  <?php if ($pendingVerif): ?><div class="alert-box warn"><strong><?php echo $pendingVerif; ?> volunteer<?php echo $pendingVerif > 1 ? "s are" : " is"; ?> waiting for verification.</strong> <a href="admin.php?tab=verification" style="text-decoration:underline;font-weight:800">Review now</a></div><?php endif; ?>

<?php elseif ($tab === "verification"):
  $rows = $pdo->query("SELECT v.*, u.first_name, u.last_name, u.email, u.phone FROM volunteers v JOIN users u ON u.id=v.user_id WHERE v.verification_status='Pending' ORDER BY v.verification_submitted_at")->fetchAll(); ?>
  <?php if (!$rows): ?><div class="empty"><strong>Nothing to review</strong><p class="muted">New submissions appear here.</p></div><?php endif; ?>
  <?php foreach ($rows as $v): ?>
    <article class="review-card">
      <h3><?php echo h($v["first_name"] . " " . $v["last_name"]); ?> <span class="vpill vpill-Pending">Pending</span></h3>
      <dl>
        <dt>Contact</dt><dd><?php echo h($v["email"]); ?> · <?php echo h($v["phone"]); ?></dd>
        <dt>Areas / availability</dt><dd><?php echo h($v["areas"]); ?> · <?php echo h($v["availability"]); ?></dd>
        <dt>Emergency contact</dt><dd><?php echo h($v["emergency_contact_name"]); ?> · <?php echo h($v["emergency_contact_phone"]); ?></dd>
        <dt>Reference 1</dt><dd><?php echo h($v["ref1_name"]); ?> · <?php echo h($v["ref1_phone"]); ?> · <?php echo h($v["ref1_relationship"]); ?></dd>
        <dt>Reference 2</dt><dd><?php echo h($v["ref2_name"]); ?> · <?php echo h($v["ref2_phone"]); ?> · <?php echo h($v["ref2_relationship"]); ?></dd>
        <dt>Submitted</dt><dd><?php echo h(date("d M Y, H:i", strtotime($v["verification_submitted_at"]))); ?></dd>
        <dt>ID document</dt><dd><a class="btn btn-ghost small" href="admin_file.php?uid=<?php echo (int)$v["user_id"]; ?>" target="_blank" rel="noopener"><i class="fa-regular fa-file"></i> Open ID (new tab)</a></dd>
      </dl>
      <form method="post" class="admin-toolbar">
        <input type="hidden" name="csrf" value="<?php echo h(csrf_token()); ?>"><input type="hidden" name="action" value="verify"><input type="hidden" name="tab" value="verification"><input type="hidden" name="uid" value="<?php echo (int)$v["user_id"]; ?>">
        <input name="note" placeholder="Reason (required if rejecting)" maxlength="255" style="flex:1;min-width:220px" aria-label="Reason for rejection">
        <button class="btn primary small" name="decision" value="approve" data-ok="1">Approve</button>
        <button class="btn danger small" name="decision" value="reject">Reject</button>
      </form>
      <p class="muted-small">Phone both references before approving. The ID file is deleted automatically once you decide.</p>
    </article>
  <?php endforeach; ?>

<?php elseif ($tab === "users"):
  $qs = trim($_GET["q"] ?? "");
  $sql = "SELECT u.*, v.status vstatus, v.verification_status vver FROM users u LEFT JOIN volunteers v ON v.user_id=u.id";
  $p = [];
  if ($qs !== "") { $sql .= " WHERE u.email LIKE ? OR u.first_name LIKE ? OR u.last_name LIKE ? OR u.phone LIKE ?"; $like = "%" . addcslashes($qs, "%_\\") . "%"; $p = [$like, $like, $like, $like]; }
  $st = $pdo->prepare($sql . " ORDER BY u.created_at DESC LIMIT 150"); $st->execute($p); $rows = $st->fetchAll(); ?>
  <form class="admin-toolbar" method="get"><input type="hidden" name="tab" value="users"><input type="search" name="q" value="<?php echo h($qs); ?>" placeholder="Search name, e-mail or phone" aria-label="Search users"><button class="btn primary small">Search</button></form>
  <div class="table-wrap"><table class="data-table admin-table"><thead><tr><th>Name</th><th>Contact</th><th>Role</th><th>Volunteer</th><th>Joined</th><th>Actions</th></tr></thead><tbody>
  <?php foreach ($rows as $u): ?><tr>
    <td><?php echo h($u["first_name"] . " " . $u["last_name"]); ?><?php echo $u["is_admin"] ? ' <span class="badge">Admin</span>' : ""; ?></td>
    <td class="wrap"><?php echo h($u["email"]); ?><br><small><?php echo h($u["phone"]); ?></small></td>
    <td><?php echo h($u["role"]); ?></td>
    <td><?php if ($u["vver"]): ?><span class="vpill vpill-<?php echo h($u["vver"]); ?>"><?php echo h($u["vver"]); ?></span><br><small><?php echo h($u["vstatus"]); ?></small><?php else: ?>—<?php endif; ?></td>
    <td><?php echo h(date("d M Y", strtotime($u["created_at"]))); ?></td>
    <td><div class="row-actions">
      <?php if ($u["vstatus"]): ?><form class="inline-form" method="post"><input type="hidden" name="csrf" value="<?php echo h(csrf_token()); ?>"><input type="hidden" name="action" value="volunteer_status"><input type="hidden" name="tab" value="users"><input type="hidden" name="uid" value="<?php echo (int)$u["id"]; ?>"><button class="btn btn-ghost small"><?php echo $u["vstatus"] === "Active" ? "Pause" : "Activate"; ?></button></form><?php endif; ?>
      <?php if ((int)$u["id"] !== (int)$admin["id"]): ?><form class="inline-form" method="post" data-confirm="<?php echo $u["is_admin"] ? "Remove" : "Give"; ?> administrator access for this person?"><input type="hidden" name="csrf" value="<?php echo h(csrf_token()); ?>"><input type="hidden" name="action" value="toggle_admin"><input type="hidden" name="tab" value="users"><input type="hidden" name="uid" value="<?php echo (int)$u["id"]; ?>"><button class="btn btn-ghost small"><?php echo $u["is_admin"] ? "Remove admin" : "Make admin"; ?></button></form><?php endif; ?>
    </div></td></tr><?php endforeach; ?>
  </tbody></table></div>

<?php elseif ($tab === "requests"):
  $fs = $_GET["status"] ?? "";
  $sql = "SELECT r.*, CONCAT(u.first_name,' ',u.last_name) requester, CONCAT(COALESCE(v.first_name,''),' ',COALESCE(v.last_name,'')) vol FROM requests r JOIN users u ON u.id=r.user_id LEFT JOIN users v ON v.id=r.volunteer_id";
  $p = [];
  if (in_array($fs, ["Pending", "Accepted", "Completed", "Cancelled"], true)) { $sql .= " WHERE r.status=?"; $p[] = $fs; }
  $st = $pdo->prepare($sql . " ORDER BY r.created_at DESC LIMIT 150"); $st->execute($p); $rows = $st->fetchAll(); ?>
  <form class="admin-toolbar" method="get"><input type="hidden" name="tab" value="requests"><select name="status" aria-label="Filter by status"><option value="">All statuses</option><?php foreach (["Pending", "Accepted", "Completed", "Cancelled"] as $s): ?><option<?php echo $fs === $s ? " selected" : ""; ?>><?php echo $s; ?></option><?php endforeach; ?></select><button class="btn primary small">Filter</button></form>
  <div class="table-wrap"><table class="data-table admin-table"><thead><tr><th>#</th><th>Help</th><th>Requester</th><th>Volunteer</th><th>When</th><th>Status</th><th></th></tr></thead><tbody>
  <?php foreach ($rows as $r): ?><tr>
    <td><?php echo (int)$r["id"]; ?></td><td class="wrap"><?php echo h($r["category"]); ?><br><small><?php echo h($r["location"]); ?></small></td>
    <td><?php echo h($r["requester"]); ?></td><td><?php echo trim($r["vol"]) !== "" ? h(trim($r["vol"])) : "—"; ?></td>
    <td><?php echo h($r["preferred_date"]); ?><br><small><?php echo h(substr($r["preferred_time"], 0, 5)); ?></small></td><td><?php echo status_pill($r["status"]); ?></td>
    <td><?php if (in_array($r["status"], ["Pending", "Accepted"], true)): ?><form class="inline-form" method="post" data-confirm="Cancel request #<?php echo (int)$r["id"]; ?>? Both people will be notified."><input type="hidden" name="csrf" value="<?php echo h(csrf_token()); ?>"><input type="hidden" name="action" value="cancel_request"><input type="hidden" name="tab" value="requests"><input type="hidden" name="rid" value="<?php echo (int)$r["id"]; ?>"><button class="btn danger small">Cancel</button></form><?php endif; ?></td></tr><?php endforeach; ?>
  </tbody></table></div>

<?php elseif ($tab === "messages"):
  $rows = $pdo->query("SELECT * FROM contact_messages ORDER BY FIELD(status,'New','Read','Resolved'), created_at DESC LIMIT 150")->fetchAll(); ?>
  <?php if (!$rows): ?><div class="empty"><strong>No messages yet</strong></div><?php endif; ?>
  <?php foreach ($rows as $m): ?>
    <article class="review-card">
      <h3><?php echo h($m["subject"]); ?> <span class="badge<?php echo $m["status"] === "New" ? "" : " orange"; ?>"><?php echo h($m["status"]); ?></span></h3>
      <p class="muted-small"><?php echo h($m["name"]); ?> · <a href="mailto:<?php echo h($m["email"]); ?>"><?php echo h($m["email"]); ?></a> · <?php echo h(date("d M Y, H:i", strtotime($m["created_at"]))); ?></p>
      <p style="margin:10px 0"><?php echo nl2br(h($m["message"])); ?></p>
      <form method="post" class="admin-toolbar"><input type="hidden" name="csrf" value="<?php echo h(csrf_token()); ?>"><input type="hidden" name="action" value="message_status"><input type="hidden" name="tab" value="messages"><input type="hidden" name="mid" value="<?php echo (int)$m["id"]; ?>">
        <select name="status" aria-label="Message status"><?php foreach (["New", "Read", "Resolved"] as $s): ?><option<?php echo $m["status"] === $s ? " selected" : ""; ?>><?php echo $s; ?></option><?php endforeach; ?></select><button class="btn btn-ghost small">Update</button></form>
    </article>
  <?php endforeach; ?>

<?php else:
  $rows = $pdo->query("SELECT * FROM email_log ORDER BY id DESC LIMIT 100")->fetchAll(); ?>
  <p class="muted-small mb">Every e-mail and SMS the site tries to send is recorded here, including password resets. If a message shows <strong>failed</strong>, check the SMTP settings in <code>site-settings.php</code>. Free hosts sometimes block outgoing mail.</p>
  <div class="table-wrap"><table class="data-table admin-table"><thead><tr><th>When</th><th>Type</th><th>To</th><th>Subject</th><th>Result</th></tr></thead><tbody>
  <?php if (!$rows): ?><tr><td colspan="5">Nothing sent yet.</td></tr><?php endif; ?>
  <?php foreach ($rows as $l): ?><tr><td><?php echo h(date("d M H:i", strtotime($l["created_at"]))); ?></td><td><?php echo h(strtoupper($l["channel"])); ?></td><td class="wrap"><?php echo h($l["to_address"]); ?></td><td class="wrap"><?php echo h($l["subject"]); ?></td>
    <td class="wrap"><span class="<?php echo $l["status"] === "sent" ? "log-ok" : "log-bad"; ?>"><?php echo h($l["status"]); ?></span><?php echo $l["error_text"] ? "<br><small>" . h($l["error_text"]) . "</small>" : ""; ?></td></tr><?php endforeach; ?>
  </tbody></table></div>
<?php endif; ?>
</div>
</section>
<?php page_end(); ?>
