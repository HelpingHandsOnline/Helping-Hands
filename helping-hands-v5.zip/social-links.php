<?php
/**
 * social-links.php — paste your REAL social media page addresses between the quotes.
 * Leave a line as "" (empty) and that icon simply will not appear on the website.
 * Example: "facebook" => "https://www.facebook.com/yourpagename",
 */
return [
    "facebook"  => "",
    "instagram" => "",
    "x"         => "",   // Twitter / X
    "youtube"   => "",
    "linkedin"  => "",
    "tiktok"    => "",
    "whatsapp"  => "",   // e.g. https://wa.me/27821234567  (country code, no + or spaces)
];
