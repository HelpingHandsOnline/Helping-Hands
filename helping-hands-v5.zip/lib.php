<?php
declare(strict_types=1);
/**
 * lib.php — shared helpers added in v5 (settings, languages, e-mail/SMS, notifications,
 * admin checks, ratings, uploads, page layout). Loaded automatically by config.php.
 */

/* ======================= Settings ======================= */
function settings(): array {
    static $s = null;
    if ($s === null) { $s = is_file(__DIR__ . '/site-settings.php') ? (include __DIR__ . '/site-settings.php') : []; if (!is_array($s)) $s = []; }
    return $s;
}
function setting(string $key, mixed $default = ''): mixed { $s = settings(); return $s[$key] ?? $default; }
function base_url(): string {
    $b = trim((string)setting('site_url', ''));
    if ($b !== '') return rtrim($b, '/');
    $https = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    $dir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '')), '/');
    $host = preg_replace('/[^a-zA-Z0-9.\-:]/', '', (string)($_SERVER['HTTP_HOST'] ?? 'localhost'));
    return ($https ? 'https' : 'http') . '://' . $host . $dir;
}

/* ======================= Languages ======================= */
function langs(): array { return ['en' => 'English', 'af' => 'Afrikaans', 'xh' => 'isiXhosa']; }
if (isset($_GET['lang']) && is_string($_GET['lang']) && isset(langs()[$_GET['lang']])) {
    if (!headers_sent()) setcookie('hh_lang', $_GET['lang'], ['expires' => time() + 31536000, 'path' => '/', 'samesite' => 'Lax']);
    $_COOKIE['hh_lang'] = $_GET['lang'];
}
function current_lang(): string { $l = $_COOKIE['hh_lang'] ?? 'en'; return (is_string($l) && isset(langs()[$l])) ? $l : 'en'; }
function t(string $key): string {
    static $d = null;
    if ($d === null) { $d = is_file(__DIR__ . '/lang.php') ? (include __DIR__ . '/lang.php') : []; }
    return $d[current_lang()][$key] ?? $d['en'][$key] ?? $key;
}
function lang_url(string $code): string {
    $q = $_GET; $q['lang'] = $code;
    return strtok($_SERVER['REQUEST_URI'] ?? 'index.php', '?') . '?' . http_build_query($q);
}

/* ======================= Small helpers ======================= */
function admin_user(): bool { $u = user(); return $u && !empty($u['is_admin']); }
function require_admin(): array {
    require_login('');
    $u = user();
    if (!$u || empty($u['is_admin'])) { http_response_code(403); flash('error', 'That page is for administrators only.'); redirect('account.php'); }
    return $u;
}
function post_id(string $key = 'id'): int { return (int)($_POST[$key] ?? 0); }
function photo(string $name, string $fallback): string {
    foreach (['jpg', 'jpeg', 'png', 'webp'] as $ext) { if (is_file(__DIR__ . "/images/photos/$name.$ext")) return "images/photos/$name.$ext"; }
    return $fallback;
}
function to_e164(string $phone): string {
    $cc = (string)(setting('sms', [])['default_country_code'] ?? '27');
    $p = preg_replace('/[^\d+]/', '', $phone) ?? '';
    if ($p === '') return '';
    if ($p[0] === '+') return $p;
    if (str_starts_with($p, '00')) return '+' . substr($p, 2);
    if ($p[0] === '0') return '+' . $cc . substr($p, 1);
    return '+' . $p;
}
function avg_rating(int $volunteerUserId): array {
    global $pdo;
    try {
        $q = $pdo->prepare('SELECT ROUND(AVG(stars),1) a, COUNT(*) c FROM ratings WHERE volunteer_id=?');
        $q->execute([$volunteerUserId]);
        $r = $q->fetch();
        return [$r['a'] !== null ? (float)$r['a'] : 0.0, (int)$r['c']];
    } catch (Throwable $e) { return [0.0, 0]; }
}
function stars_html(float $avg, int $count = 0): string {
    if ($count === 0) return '<span class="muted">No ratings yet</span>';
    $full = (int)round($avg); $s = '';
    for ($i = 1; $i <= 5; $i++) $s .= '<i class="' . ($i <= $full ? 'fa-solid' : 'fa-regular') . ' fa-star" aria-hidden="true"></i>';
    return '<span class="stars" aria-label="' . h((string)$avg) . ' out of 5 from ' . $count . ' rating(s)">' . $s . '</span> <small>' . h((string)$avg) . ' (' . $count . ')</small>';
}
function status_pill(string $status): string {
    $map = ['Pending' => 'status-pending', 'Accepted' => 'status-accepted', 'Completed' => 'status-completed', 'Cancelled' => 'status-cancelled'];
    return '<span class="status-pill ' . ($map[$status] ?? '') . '">' . h($status) . '</span>';
}

/* ======================= E-mail ======================= */
function email_wrap(string $title, string $bodyHtml, string $link = '', string $cta = 'Open Helping Hands'): string {
    $btn = $link !== '' ? '<p style="margin:26px 0"><a href="' . h($link) . '" style="background:#e3a72f;color:#0b3329;padding:12px 22px;border-radius:10px;text-decoration:none;font-weight:700;display:inline-block">' . h($cta) . '</a></p>' : '';
    return '<!doctype html><html><body style="margin:0;background:#fbf8f2;font-family:Arial,Helvetica,sans-serif;color:#16302a">'
        . '<div style="max-width:560px;margin:0 auto;padding:24px"><div style="background:#0b3329;color:#fff;padding:18px 24px;border-radius:14px 14px 0 0;font-size:20px"><strong>Helping Hands</strong> <span style="color:#e3a72f;font-size:11px;letter-spacing:2px">COMMUNITY ASSIST</span></div>'
        . '<div style="background:#fff;padding:26px 24px;border:1px solid #e6dfd1;border-top:0;border-radius:0 0 14px 14px"><h2 style="margin:0 0 12px;color:#0f4236;font-size:20px">' . h($title) . '</h2>'
        . '<div style="font-size:15px;line-height:1.6">' . $bodyHtml . '</div>' . $btn
        . '<p style="font-size:12px;color:#55675f;margin-top:26px">Helping Hands is not an emergency service. In an emergency, call your local emergency services.</p></div></div></body></html>';
}
function log_message(?int $userId, string $channel, string $to, string $subject, string $body, string $status, string $error = ''): void {
    global $pdo;
    try {
        $pdo->prepare('INSERT INTO email_log (user_id, channel, to_address, subject, body, status, error_text) VALUES (?,?,?,?,?,?,?)')
            ->execute([$userId, $channel, $to, mb_substr($subject, 0, 250), mb_substr($body, 0, 4000), $status, mb_substr($error, 0, 500)]);
    } catch (Throwable $e) { /* logging must never break a page */ }
}
function send_mail(string $to, string $subject, string $html, ?int $userId = null): bool {
    $to = trim(str_replace(["\r", "\n"], '', $to));
    $subject = trim(str_replace(["\r", "\n"], ' ', $subject));
    if (!filter_var($to, FILTER_VALIDATE_EMAIL)) { log_message($userId, 'email', $to, $subject, '', 'failed', 'Invalid address'); return false; }
    $text = trim(html_entity_decode(strip_tags(preg_replace('~<(br|/p|/h2|/div)>~i', "\n", $html) ?? $html), ENT_QUOTES, 'UTF-8'));
    $smtp = setting('smtp', []);
    $err = ''; $ok = false;
    if (!empty($smtp['host'])) {
        $ok = smtp_send($smtp, $to, $subject, $html, $text, $err);
    } else {
        $from = (string)($smtp['from_email'] ?? '') ?: 'no-reply@' . preg_replace('/^www\./', '', (string)($_SERVER['HTTP_HOST'] ?? 'localhost'));
        $headers = "MIME-Version: 1.0\r\nContent-Type: text/html; charset=UTF-8\r\nFrom: Helping Hands <$from>\r\n";
        $ok = @mail($to, '=?UTF-8?B?' . base64_encode($subject) . '?=', $html, $headers);
        if (!$ok) $err = 'No SMTP host configured and PHP mail() is unavailable on this server.';
    }
    log_message($userId, 'email', $to, $subject, $text, $ok ? 'sent' : 'failed', $err);
    return $ok;
}
function smtp_send(array $c, string $to, string $subject, string $html, string $text, string &$err): bool {
    $host = (string)$c['host']; $port = (int)($c['port'] ?? 587); $enc = (string)($c['encryption'] ?? 'tls');
    $fromEmail = (string)($c['from_email'] ?: ($c['username'] ?? '')); $fromName = str_replace(["\r", "\n", '"'], '', (string)($c['from_name'] ?? 'Helping Hands'));
    if ($fromEmail === '') { $err = 'from_email is empty in site-settings.php'; return false; }
    $fp = @stream_socket_client(($enc === 'ssl' ? 'ssl://' : 'tcp://') . $host . ':' . $port, $errno, $errstr, 12);
    if (!$fp) { $err = "Could not connect to $host:$port ($errstr). Free hosts often block SMTP."; return false; }
    stream_set_timeout($fp, 12);
    $read = function () use ($fp): string {
        $data = '';
        while (($line = fgets($fp, 515)) !== false) { $data .= $line; if (strlen($line) < 4 || $line[3] === ' ') break; }
        return $data;
    };
    $cmd = function (string $line, array $ok) use ($fp, $read, &$err): bool {
        if ($line !== '') fwrite($fp, $line . "\r\n");
        $r = $read();
        if (!in_array((int)substr($r, 0, 3), $ok, true)) { $err = trim($r) ?: 'No reply from server'; return false; }
        return true;
    };
    $ehlo = 'EHLO ' . (preg_replace('/[^a-zA-Z0-9.\-]/', '', (string)($_SERVER['SERVER_NAME'] ?? 'localhost')) ?: 'localhost');
    $done = false;
    do {
        if (!$cmd('', [220])) break;
        if (!$cmd($ehlo, [250])) break;
        if ($enc === 'tls') {
            if (!$cmd('STARTTLS', [220])) break;
            if (!@stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) { $err = 'TLS handshake failed'; break; }
            if (!$cmd($ehlo, [250])) break;
        }
        if (!empty($c['username'])) {
            if (!$cmd('AUTH LOGIN', [334])) break;
            if (!$cmd(base64_encode((string)$c['username']), [334])) break;
            if (!$cmd(base64_encode((string)$c['password']), [235])) break;
        }
        if (!$cmd("MAIL FROM:<$fromEmail>", [250])) break;
        if (!$cmd("RCPT TO:<$to>", [250, 251])) break;
        if (!$cmd('DATA', [354])) break;
        $b = 'hh' . bin2hex(random_bytes(8));
        $msg = "Date: " . date('r') . "\r\nFrom: \"$fromName\" <$fromEmail>\r\nTo: <$to>\r\nSubject: =?UTF-8?B?" . base64_encode($subject) . "?=\r\n"
             . "Message-ID: <" . bin2hex(random_bytes(10)) . "@" . preg_replace('/[^a-zA-Z0-9.\-]/', '', $host) . ">\r\nMIME-Version: 1.0\r\n"
             . "Content-Type: multipart/alternative; boundary=\"$b\"\r\n\r\n"
             . "--$b\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n" . chunk_split(base64_encode($text)) . "\r\n"
             . "--$b\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n" . chunk_split(base64_encode($html)) . "\r\n--$b--\r\n";
        fwrite($fp, $msg . "\r\n.\r\n");
        $r = $read();
        if ((int)substr($r, 0, 3) !== 250) { $err = trim($r); break; }
        $done = true;
        @fwrite($fp, "QUIT\r\n");
    } while (false);
    @fclose($fp);
    return $done;
}

/* ======================= SMS (optional, Twilio) ======================= */
function send_sms(string $phone, string $message, ?int $userId = null): bool {
    $c = setting('sms', []);
    if (($c['provider'] ?? '') !== 'twilio' || empty($c['account_sid']) || empty($c['auth_token']) || empty($c['from'])) return false;
    $to = to_e164($phone);
    if (!preg_match('/^\+\d{8,15}$/', $to)) { log_message($userId, 'sms', $to, 'SMS', $message, 'failed', 'Invalid phone number'); return false; }
    if (!function_exists('curl_init')) { log_message($userId, 'sms', $to, 'SMS', $message, 'failed', 'cURL not available'); return false; }
    $ch = curl_init('https://api.twilio.com/2010-04-01/Accounts/' . rawurlencode((string)$c['account_sid']) . '/Messages.json');
    curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 12,
        CURLOPT_USERPWD => $c['account_sid'] . ':' . $c['auth_token'],
        CURLOPT_POSTFIELDS => http_build_query(['From' => $c['from'], 'To' => $to, 'Body' => mb_substr($message, 0, 300)])]);
    $res = curl_exec($ch); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); $e = curl_error($ch); curl_close($ch);
    $ok = $code >= 200 && $code < 300;
    log_message($userId, 'sms', $to, 'SMS', $message, $ok ? 'sent' : 'failed', $ok ? '' : ($e ?: (string)$res));
    return $ok;
}

/* ======================= Notifications ======================= */
function notify(int $userId, string $type, string $title, string $body = '', string $link = '', bool $external = true): void {
    global $pdo;
    try {
        $pdo->prepare('INSERT INTO notifications (user_id, type, title, body, link) VALUES (?,?,?,?,?)')->execute([$userId, $type, $title, $body, $link]);
        if (!$external) return;
        $q = $pdo->prepare('SELECT email, phone, first_name, notify_email, notify_sms FROM users WHERE id=?');
        $q->execute([$userId]);
        $u = $q->fetch();
        if (!$u) return;
        $abs = $link !== '' ? base_url() . '/' . ltrim($link, '/') : '';
        if ((int)$u['notify_email'] === 1) {
            send_mail($u['email'], $title . ' — Helping Hands', email_wrap($title, '<p>Hi ' . h($u['first_name']) . ',</p><p>' . nl2br(h($body)) . '</p>', $abs, 'View on Helping Hands'), $userId);
        }
        if ((int)$u['notify_sms'] === 1) send_sms($u['phone'], 'Helping Hands: ' . $title . '. ' . $body, $userId);
    } catch (Throwable $e) { /* notifications must never break the action that triggered them */ }
}
function notify_admins(string $type, string $title, string $body, string $link): void {
    global $pdo;
    try { foreach ($pdo->query('SELECT id FROM users WHERE is_admin=1')->fetchAll() as $a) notify((int)$a['id'], $type, $title, $body, $link, false); } catch (Throwable $e) {}
}
function unread_count(): int {
    global $pdo;
    if (!logged_in()) return 0;
    try { $q = $pdo->prepare('SELECT COUNT(*) FROM notifications WHERE user_id=? AND is_read=0'); $q->execute([(int)$_SESSION['user_id']]); return (int)$q->fetchColumn(); }
    catch (Throwable $e) { return 0; }
}

/* ======================= Private uploads (ID documents) ======================= */
function save_private_upload(array $file, string $dir, int $maxBytes = 3145728): array {
    // returns [storedName|null, error|null]
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) return [null, 'Please attach a photo or PDF of your ID document.'];
    if (($file['error'] ?? 1) !== UPLOAD_ERR_OK) return [null, 'The upload failed. Please try again with a smaller file.'];
    if ($file['size'] > $maxBytes) return [null, 'The file is too large. The limit is 3 MB.'];
    $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'application/pdf' => 'pdf'];
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
    if (!isset($allowed[$mime])) return [null, 'Only JPG, PNG or PDF files are accepted.'];
    $full = __DIR__ . '/' . trim($dir, '/');
    if (!is_dir($full) && !@mkdir($full, 0755, true)) return [null, 'The server could not create the upload folder.'];
    $htaccess = $full . '/.htaccess';
    if (!is_file($htaccess)) @file_put_contents($htaccess, "Options -Indexes\n<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nOrder allow,deny\nDeny from all\n</IfModule>\n");
    if (!is_file($full . '/index.html')) @file_put_contents($full . '/index.html', '');
    $name = bin2hex(random_bytes(16)) . '.' . $allowed[$mime];
    if (!move_uploaded_file($file['tmp_name'], $full . '/' . $name)) return [null, 'The server could not save the file.'];
    return [$name, null];
}

/* ======================= Page layout for the new pages ======================= */
function page_start(string $title, array $css = [], string $active = '', string $description = ''): void {
    global $pdo;
    $activePage = $active;
    $desc = $description !== '' ? $description : 'Helping Hands Community Assist connects neighbours who need support with volunteers who want to help.';
    echo '<!doctype html><html lang="' . h(current_lang()) . '"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">';
    echo '<title>Helping Hands | ' . h($title) . '</title><meta name="description" content="' . h($desc) . '"><meta name="robots" content="noindex">';
    echo '<link rel="icon" href="logo.png"><link rel="manifest" href="manifest.webmanifest"><meta name="theme-color" content="#0b3329">';
    echo '<link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,600;0,700;1,600&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">';
    echo '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"><link rel="stylesheet" href="common.css?v=5"><link rel="stylesheet" href="request.css?v=5"><link rel="stylesheet" href="v5.css?v=5">';
    foreach ($css as $c) echo '<link rel="stylesheet" href="' . h($c) . '?v=5">';
    echo '<link rel="stylesheet" href="polish.css?v=1">';
    echo '</head><body><a class="skip-link" href="#main">' . h(t('skip')) . '</a>';
    include __DIR__ . '/partials/header.php';
    echo '<main id="main">';
}
function page_end(): void {
    echo '</main>';
    include __DIR__ . '/partials/footer.php';
    echo '</body></html>';
}
