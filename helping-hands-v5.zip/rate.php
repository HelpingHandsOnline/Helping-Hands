<?php
require __DIR__ . "/config.php";
require_login("rate");
$me = user();
$rid = (int)($_GET["request_id"] ?? $_POST["request_id"] ?? 0);

$q = $pdo->prepare("SELECT r.*, v.first_name vfirst FROM requests r JOIN users v ON v.id = r.volunteer_id WHERE r.id = ? AND r.user_id = ? AND r.status = 'Completed'");
$q->execute([$rid, $me["id"]]);
$req = $q->fetch();
if (!$req) { flash("error", "You can only rate your own completed requests."); redirect("tasks.php"); }

$done = $pdo->prepare("SELECT 1 FROM ratings WHERE request_id = ?");
$done->execute([$rid]);
if ($done->fetchColumn()) { flash("success", "You have already rated this request. Thank you!"); redirect("tasks.php"); }

$errors = [];
$stars = 0; $comment = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    verify_csrf();
    $stars = (int)($_POST["stars"] ?? 0);
    $comment = trim($_POST["comment"] ?? "");
    if ($stars < 1 || $stars > 5) $errors[] = "Please choose between 1 and 5 stars.";
    if (mb_strlen($comment) > 500) $errors[] = "Please keep your comment under 500 characters.";
    if (!$errors) {
        try {
            $pdo->prepare("INSERT INTO ratings (request_id, rater_id, volunteer_id, stars, comment) VALUES (?,?,?,?,?)")
                ->execute([$rid, $me["id"], $req["volunteer_id"], $stars, $comment !== "" ? $comment : null]);
            notify((int)$req["volunteer_id"], "rating", "You received a rating", $me["first_name"] . " rated your help with the " . $req["category"] . " request " . str_repeat("★", $stars) . str_repeat("☆", 5 - $stars) . ($comment !== "" ? ". They said: \"" . $comment . "\"" : "."), "tasks.php");
            flash("success", "Thank you for your feedback!");
            redirect("tasks.php");
        } catch (PDOException $e) {
            flash("success", "You have already rated this request. Thank you!");
            redirect("tasks.php");
        }
    }
}

page_start("Rate Your Volunteer", [], "tasks");
?>
<div class="container page-top">
  <span class="eyebrow">FEEDBACK</span>
  <h1>How did it go?</h1>
  <p>Your rating helps other neighbours choose with confidence and helps us recognise reliable volunteers.</p>
</div>
<section class="section" style="padding-top:18px">
  <div class="container wrap-narrow">
    <form class="form-card" method="post" novalidate>
      <input type="hidden" name="csrf" value="<?php echo h(csrf_token()); ?>">
      <input type="hidden" name="request_id" value="<?php echo (int)$rid; ?>">
      <h2><?php echo h($req["vfirst"]); ?> helped with your <?php echo h(strtolower($req["category"])); ?> request</h2>
      <p class="lead-sm"><?php echo h(date("d M Y", strtotime($req["preferred_date"]))); ?> · <?php echo h($req["location"]); ?></p>
      <?php if ($errors): ?><div class="form-errors"><?php echo implode("<br>", array_map("h", $errors)); ?></div><?php endif; ?>
      <fieldset style="border:0">
        <legend class="sr-only">Star rating</legend>
        <div class="star-input" role="radiogroup" aria-label="Rating out of 5">
          <?php for ($i = 5; $i >= 1; $i--): ?>
            <input type="radio" id="star<?php echo $i; ?>" name="stars" value="<?php echo $i; ?>"<?php echo $stars === $i ? " checked" : ""; ?> required><label for="star<?php echo $i; ?>" title="<?php echo $i; ?> star<?php echo $i > 1 ? "s" : ""; ?>"><span aria-hidden="true">★</span><span class="sr-only"><?php echo $i; ?> star<?php echo $i > 1 ? "s" : ""; ?></span></label>
          <?php endfor; ?>
        </div>
      </fieldset>
      <div class="field" style="margin-top:18px"><label for="comment">Comment <span class="hint">Optional, up to 500 characters</span></label><textarea id="comment" name="comment" maxlength="500" placeholder="Was the volunteer on time, kind and helpful?"><?php echo h($comment); ?></textarea></div>
      <p class="muted-small mb">If something went wrong or you felt unsafe, please <a href="contact.php" style="text-decoration:underline">contact us</a> as well so we can follow up.</p>
      <div class="row-actions"><a class="btn btn-ghost" href="tasks.php">Maybe later</a><button class="btn btn-orange" type="submit">Submit rating <i class="fa-solid fa-star"></i></button></div>
    </form>
  </div>
</section>
<?php page_end(); ?>
