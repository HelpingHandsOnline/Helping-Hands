<?php
require __DIR__ . "/config.php";
require_login("tasks");
$me = user();
$id = (int)($_GET["id"] ?? $_POST["id"] ?? 0);

$q = $pdo->prepare("SELECT * FROM requests WHERE id = ? AND user_id = ?");
$q->execute([$id, $me["id"]]);
$req = $q->fetch();
if (!$req) { flash("error", "We could not find that request."); redirect("tasks.php"); }
if ($req["status"] !== "Pending") {
    flash("error", $req["status"] === "Accepted"
        ? "A volunteer has already accepted this request, so it can no longer be edited. You can cancel it and submit a new one."
        : "Only requests that are still pending can be edited.");
    redirect("tasks.php");
}

$categories = ["Grocery Shopping", "Prescription Pickup", "Medical Transport", "Household Tasks", "Companionship", "Other"];
$methods = ["Phone call", "SMS / WhatsApp", "Email"];
$errors = [];
$old = ["category" => $req["category"], "location" => $req["location"], "prefDate" => $req["preferred_date"],
        "prefTime" => substr($req["preferred_time"], 0, 5), "notes" => (string)$req["notes"], "contactMethod" => $req["contact_method"]];

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    verify_csrf();
    foreach ($old as $k => $_) $old[$k] = trim($_POST[$k] ?? "");
    if (!in_array($old["category"], $categories, true)) $errors[] = "Please choose a category.";
    if ($old["location"] === "") $errors[] = "Please tell us where help is needed.";
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $old["prefDate"])) $errors[] = "Please choose a preferred date.";
    elseif ($old["prefDate"] < date("Y-m-d")) $errors[] = "The preferred date cannot be in the past.";
    if (!preg_match('/^\d{2}:\d{2}$/', $old["prefTime"])) $errors[] = "Please choose a preferred time.";
    if (!in_array($old["contactMethod"], $methods, true)) $old["contactMethod"] = "Phone call";

    if (!$errors) {
        $pdo->beginTransaction();
        $chk = $pdo->prepare("SELECT status FROM requests WHERE id = ? AND user_id = ? FOR UPDATE");
        $chk->execute([$id, $me["id"]]);
        if ($chk->fetchColumn() !== "Pending") {
            $pdo->rollBack();
            flash("error", "A volunteer accepted this request while you were editing, so it can no longer be changed.");
            redirect("tasks.php");
        }
        $pdo->prepare("UPDATE requests SET category=?, location=?, preferred_date=?, preferred_time=?, notes=?, contact_method=?, updated_at=NOW() WHERE id=?")
            ->execute([$old["category"], $old["location"], $old["prefDate"], $old["prefTime"], $old["notes"], $old["contactMethod"], $id]);
        $pdo->commit();
        flash("success", "Your request has been updated.");
        redirect("tasks.php");
    }
}

page_start("Edit Request", [], "tasks");
?>
<div class="container page-top">
  <span class="eyebrow">MY REQUESTS</span>
  <h1>Edit your request</h1>
  <p>You can change the details while the request is still pending. Once a volunteer accepts it, it is locked.</p>
</div>
<section class="section" style="padding-top:18px">
  <div class="container wrap-narrow">
    <form class="form-card" method="post" novalidate>
      <input type="hidden" name="csrf" value="<?php echo h(csrf_token()); ?>">
      <input type="hidden" name="id" value="<?php echo (int)$id; ?>">
      <?php if ($errors): ?><div class="form-errors"><ul><?php foreach ($errors as $e): ?><li><?php echo h($e); ?></li><?php endforeach; ?></ul></div><?php endif; ?>
      <div class="field"><label for="category">Kind of help</label>
        <select id="category" name="category"><?php foreach ($categories as $c): ?><option<?php echo $old["category"] === $c ? " selected" : ""; ?>><?php echo h($c); ?></option><?php endforeach; ?></select></div>
      <div class="field"><label for="location">Location</label><input id="location" name="location" required value="<?php echo h($old["location"]); ?>" maxlength="255"></div>
      <div class="form-row">
        <div class="field"><label for="prefDate">Preferred date</label><input id="prefDate" name="prefDate" type="date" required min="<?php echo h(date("Y-m-d")); ?>" value="<?php echo h($old["prefDate"]); ?>"></div>
        <div class="field"><label for="prefTime">Preferred time</label><input id="prefTime" name="prefTime" type="time" required value="<?php echo h($old["prefTime"]); ?>"></div>
      </div>
      <div class="field"><label for="notes">Additional notes <span class="hint">Optional</span></label><textarea id="notes" name="notes"><?php echo h($old["notes"]); ?></textarea></div>
      <div class="field"><label for="contactMethod">Preferred contact method</label>
        <select id="contactMethod" name="contactMethod"><?php foreach ($methods as $m): ?><option<?php echo $old["contactMethod"] === $m ? " selected" : ""; ?>><?php echo h($m); ?></option><?php endforeach; ?></select></div>
      <div class="row-actions"><a class="btn btn-ghost" href="tasks.php">Back</a><button class="btn btn-orange" type="submit">Save changes <i class="fa-solid fa-check"></i></button></div>
    </form>
  </div>
</section>
<?php page_end(); ?>
