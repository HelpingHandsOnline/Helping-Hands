HELPING HANDS — INFINITYFREE FINAL UPLOAD PACKAGE

1. Extract this ZIP on your computer.
2. Do NOT upload the ZIP itself as the website.
3. Open the extracted folder.
4. In InfinityFree, open the website's htdocs folder.
5. Upload ALL files and folders from this package directly into htdocs.
6. Make sure htdocs/index.php exists directly in htdocs.
7. Open config.php and replace the four database placeholders with your InfinityFree MySQL values.
8. In phpMyAdmin, select your InfinityFree database and import schema.sql.
9. Confirm these tables exist: users, requests, volunteers, contact_messages, newsletter_subscribers.
10. Open your website domain.

IMPORTANT:
- Do not use localhost, root, or a blank password on InfinityFree.
- Do not put index.php inside an extra helping-hands folder.
- This package intentionally has no custom .htaccess file while the site is being deployed. This avoids unnecessary 403 configuration problems.
- schema.sql is a fresh-install/reset script. It deletes the five Helping Hands tables before recreating them. Do not import it on a live site if you need to preserve existing data.

If the site shows InfinityFree 403 Forbidden:
A. Check that index.php is directly inside the correct htdocs directory.
B. Check InfinityFree Client Area > Accounts > your site > Domains > Directory Status and confirm the domain points to the same htdocs folder.
C. Confirm there is no custom .htaccess blocking access.
D. Test in a private/incognito browser window.
E. If the domain was newly created, allow time for DNS/domain activation.

If the site opens but shows "Helping Hands needs its database":
That means PHP is working and only the database connection still needs to be configured. Check config.php and import schema.sql.
