HOMEPAGE SLIDESHOW: PHOTOS AND VIDEO
=====================================
Drop files in THIS folder with these exact names. They replace the illustrations automatically.
Nothing else needs editing: the slideshow timing and animation stay exactly as they are.

PHOTOS (recommended)        hero-1.jpg  hero-2.jpg  hero-3.jpg  hero-4.jpg   (.jpg .jpeg .webp .png)
  Size:   1920 x 900 px (landscape), under 300 KB each. Export at JPG quality 70-80 or use WebP.
  Framing: keep the people on the RIGHT half of the picture. The left side is darkened so the headline stays readable.
  Shots that match the slides:
    1  Volunteer and an older neighbour talking at a front door  ("Neighbours helping neighbours")
    2  Volunteer carrying groceries / collecting a prescription   ("Everyday errands")
    3  Volunteer driver and passenger at a car, going to a clinic ("A lift to appointments")
    4  Two people sharing tea or a friendly chat                  ("Safe, simple, close to home")

VIDEO (optional, use sparingly)   hero-1.mp4 (or .webm)   also hero-2..4
  8-15 seconds, looping, NO sound, 1280 x 720, H.264, under 3 MB. Keep the matching hero-N.jpg as the poster.
  Plays only while its slide is showing. Skipped on Data Saver and "reduce motion" phones (the photo shows instead).

BEFORE YOU PUBLISH
  - Use photos you took or have written permission to use (people in the photo must agree, and
    for vulnerable people or children get consent in writing: POPIA).
  - Free licensed sources if you have no photos yet: Unsplash, Pexels (check each licence and do not use a photo that
    shows a recognisable person in a way that implies they are a Helping Hands member).
  - Do not use AI-generated people and present them as real volunteers or clients.
