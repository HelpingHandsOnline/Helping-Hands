<?php require __DIR__ . "/config.php"; $activePage = "about"; ?>
<!doctype html>
<html lang="<?php echo h(current_lang()); ?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Helping Hands | About Us</title>
<meta name="description" content="Helping Hands Community Assist is a community-driven platform connecting neighbours with volunteers to build stronger, more connected communities.">
<meta property="og:type" content="website">
<meta property="og:title" content="Helping Hands | About Us">
<meta property="og:description" content="Helping Hands Community Assist is a community-driven platform connecting neighbours with volunteers to build stronger, more connected communities.">
<meta property="og:image" content="logo.png">
<meta property="og:site_name" content="Helping Hands Community Assist">
<meta name="twitter:card" content="summary">
<meta name="twitter:title" content="Helping Hands | About Us">
<meta name="twitter:description" content="Helping Hands Community Assist is a community-driven platform connecting neighbours with volunteers to build stronger, more connected communities.">
<link rel="icon" href="logo.png"><link rel="manifest" href="manifest.webmanifest"><meta name="theme-color" content="#0b3329">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,600;0,700;1,600&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<link rel="stylesheet" href="common.css?v=5"><link rel="stylesheet" href="v5.css?v=5">
<link rel="stylesheet" href="about.css?v=5">
<link rel="stylesheet" href="polish.css?v=1">
</head>
<body>
<a class="skip-link" href="#main">Skip to content</a>

<?php include __DIR__ . "/partials/header.php"; ?>

<main id="main">

<section class="page-hero hero">
  <div class="container hero-grid">
    <div class="hero-copy">
      <span class="eyebrow">OUR STORY</span>
      <h1>About <span>Us.</span></h1>
      <p>We are a community-driven platform that connects neighbours with volunteers to create stronger, caring, and more connected communities.</p>
      <div class="hero-actions">
        <a class="btn btn-orange" href="volunteer.php">Join Us <i class="fa-solid fa-arrow-right"></i></a>
        <a class="btn btn-ghost" href="contact.php">Get In Touch</a>
      </div>
    </div>
    <div class="hero-image-wrap with-orbit">
      <img class="hero-image" src="<?php echo h(photo('about-1', 'https://images.unsplash.com/photo-1521791136064-7986c2920216?auto=format&fit=crop&w=1100&q=88')); ?>" alt="A diverse group of volunteers smiling together outdoors" onerror="this.onerror=null;this.src='images/illus-community.svg'">
    </div>
  </div>
</section>

<?php $guide = ["who"=>"Anyone who wants to know who runs Helping Hands, what we believe in and how the service is meant to work, including neighbours, volunteers and partners.","what"=>"Read our mission and values, learn how requests are handled, and see what to expect before you sign up.","next"=>[["How it works","howitworks.php"],["Become a volunteer","volunteer.php"],["Contact us","contact.php"]]]; include __DIR__ . "/partials/page-guide.php"; ?>

<section class="section" aria-labelledby="story-title">
  <div class="container split">
    <div class="split-media reveal reveal-left"><div class="img-frame"><img src="images/illus-hands.svg" alt="Illustration of two hands holding a heart" width="640" height="440" loading="lazy"></div></div>
    <div class="reveal reveal-right">
      <span class="eyebrow">Why Helping Hands exists</span>
      <h2 id="story-title" style="font-size:clamp(28px,3.6vw,38px);margin:8px 0 14px">Small favours make a big difference</h2>
      <p class="lead">Most of us have, at some point, needed a hand with something ordinary: carrying shopping, collecting a prescription, getting to an appointment. For some neighbours, those everyday tasks are a real struggle. For others, there is time and willingness to help, but no easy way to find out who needs it.</p>
      <p class="lead">Helping Hands is a simple bridge between the two. It is a community platform where people can ask for practical help and where local volunteers can choose the tasks they are able to take on.</p>
    </div>
  </div>
</section>

<section class="section tint" aria-labelledby="mv-title">
  <div class="container">
    <div class="section-title reveal"><span class="eyebrow">Mission and vision</span><h2 id="mv-title">What we are working towards</h2></div>
    <div class="who-grid">
      <article class="panel who-card reveal reveal-left"><div class="category-icon" style="margin:0 0 14px"><i class="fa-solid fa-bullseye" aria-hidden="true"></i></div><h3>Our mission</h3><p style="color:var(--muted);line-height:1.8">To make it easy and safe for neighbours to ask for, and offer, practical everyday help, so that nobody in the community has to cope alone with a task they cannot manage.</p></article>
      <article class="panel who-card reveal reveal-right"><div class="category-icon" style="margin:0 0 14px"><i class="fa-regular fa-eye" aria-hidden="true"></i></div><h3>Our vision</h3><p style="color:var(--muted);line-height:1.8">A neighbourhood where asking for help is normal, offering help is easy, and small acts of kindness are part of everyday life.</p></article>
    </div>
  </div>
</section>

<section class="section" aria-labelledby="do-title">
  <div class="container">
    <div class="section-title reveal"><span class="eyebrow">How we work</span><h2 id="do-title">The principles behind the platform</h2><p>These ideas shape how Helping Hands is designed and how we expect everyone to use it.</p></div>
    <div class="principles">
      <div class="principle reveal reveal-1"><h3><i class="fa-solid fa-people-arrows" aria-hidden="true"></i> Neighbour to neighbour</h3><p>Help comes from people nearby, which keeps requests practical and relationships personal.</p></div>
      <div class="principle reveal reveal-2"><h3><i class="fa-solid fa-hand-pointer" aria-hidden="true"></i> Everyone chooses</h3><p>Requesters decide what they need. Volunteers decide what they can do. Nobody is assigned a task they have not agreed to.</p></div>
      <div class="principle reveal reveal-3"><h3><i class="fa-solid fa-lock" aria-hidden="true"></i> Privacy first</h3><p>Contact details are shared only after a volunteer accepts a request, and we ask only for the information we need.</p></div>
      <div class="principle reveal reveal-1"><h3><i class="fa-solid fa-feather" aria-hidden="true"></i> Keep it simple</h3><p>Plain forms, clear wording and a short path from request to completed task.</p></div>
      <div class="principle reveal reveal-2"><h3><i class="fa-solid fa-clock" aria-hidden="true"></i> Reliability matters</h3><p>When someone is counting on you, turning up on time matters. We encourage volunteers to accept only what they can do.</p></div>
      <div class="principle reveal reveal-3"><h3><i class="fa-solid fa-hands-holding-circle" aria-hidden="true"></i> Dignity always</h3><p>Asking for help takes courage. Every request is treated with respect and without judgement.</p></div>
    </div>
  </div>
</section>

<section class="section tint" aria-labelledby="journey-title">
  <div class="container">
    <div class="section-title reveal"><span class="eyebrow">In detail</span><h2 id="journey-title">A request from start to finish</h2><p>Here is what actually happens behind the scenes on Helping Hands.</p></div>
    <div class="timeline">
      <div class="tl-item reveal"><div class="tl-num">1</div><div><h3>You create an account</h3><p>Signing up takes a minute. You give your name, email, phone number and choose whether you are joining to ask for help, to volunteer, or both.</p></div></div>
      <div class="tl-item reveal"><div class="tl-num">2</div><div><h3>A request is submitted</h3><p>The requester describes the task, picks a category, says where and when it is needed, and chooses how they would like to be contacted. The request is saved as <strong>Pending</strong>.</p></div></div>
      <div class="tl-item reveal"><div class="tl-num">3</div><div><h3>Volunteers see open requests</h3><p>Volunteers with an active profile can browse pending requests in the Task Centre and pick one that fits their availability.</p></div></div>
      <div class="tl-item reveal"><div class="tl-num">4</div><div><h3>One volunteer accepts</h3><p>When a volunteer accepts, the request is taken, so it no longer appears to other volunteers. This avoids double bookings and confusion about who is coming.</p></div></div>
      <div class="tl-item reveal"><div class="tl-num">5</div><div><h3>Details are shared and help happens</h3><p>Once accepted, the requester and volunteer can get in touch to arrange the details, and the volunteer completes the task.</p></div></div>
      <div class="tl-item reveal"><div class="tl-num">6</div><div><h3>The task is marked complete</h3><p>The volunteer marks the task complete in the Task Centre, and the request is recorded as finished on both accounts.</p></div></div>
    </div>
  </div>
</section>

<section class="section" aria-labelledby="scope-title">
  <div class="container">
    <div class="section-title reveal"><span class="eyebrow">Being clear</span><h2 id="scope-title">What Helping Hands is, and is not</h2><p>Knowing the limits helps everyone stay safe and have the right expectations.</p></div>
    <div class="dos-donts">
      <div class="panel reveal reveal-left yes"><h3>Helping Hands is</h3><ul>
        <li>A way to ask for everyday practical help, such as shopping, prescriptions, lifts and errands</li>
        <li>A way for local people to volunteer a little of their time</li>
        <li>A simple system for tracking a request from pending to complete</li>
        <li>A place where your contact details are shared only after a volunteer accepts</li></ul></div>
      <div class="panel reveal reveal-right no"><h3>Helping Hands is not</h3><ul>
        <li>An emergency service. In an emergency, call your local emergency services</li>
        <li>A medical, nursing or professional care service</li>
        <li>A replacement for family, carers or professional support where those are needed</li>
        <li>A way to be pressured into helping. Volunteers always choose what they accept</li></ul></div>
    </div>
  </div>
</section>

<section class="section tint" aria-labelledby="trust-title">
  <div class="container split flip">
    <div class="split-media reveal reveal-right"><div class="img-frame"><img src="images/illus-safety.svg" alt="Illustration of a shield with a check mark" width="640" height="440" loading="lazy"></div></div>
    <div class="reveal reveal-left">
      <span class="eyebrow">Safety and privacy</span>
      <h2 id="trust-title" style="font-size:clamp(28px,3.6vw,38px);margin:8px 0 14px">Looking after the people involved</h2>
      <p class="lead">Trust is the whole point. Here is how the platform protects the people who use it:</p>
      <ul class="feature-list" style="display:grid;gap:12px;margin-bottom:22px">
        <li><span>Volunteers apply with their details and an <strong>emergency contact</strong>.</span></li>
        <li><span>Requester contact details are shared only <strong>after a volunteer accepts</strong>.</span></li>
        <li><span>Passwords are stored in scrambled (hashed) form, never as plain text.</span></li>
        <li><span>Forms are protected against forgery, and information is handled as described in our <a href="privacy.php" style="color:var(--gold-deep);font-weight:700">Privacy Policy</a>.</span></li>
      </ul>
      <a class="btn btn-ghost" href="privacy.php">Read the Privacy Policy</a>
    </div>
  </div>
</section>

<section class="section" id="about-faq" aria-labelledby="afaq-title">
  <div class="container">
    <div class="section-title reveal"><span class="eyebrow">Questions about us</span><h2 id="afaq-title">Good to know</h2></div>
    <div class="faq-list">
      <div class="faq-item"><button class="faq-q" type="button">Who can use Helping Hands? <i class="fa-solid fa-plus" aria-hidden="true"></i></button><div class="faq-a"><p>Anyone can create an account. You can use it to ask for help, to volunteer, or to do both.</p></div></div>
      <div class="faq-item"><button class="faq-q" type="button">What kind of help can I ask for? <i class="fa-solid fa-plus" aria-hidden="true"></i></button><div class="faq-a"><p>Everyday practical tasks such as grocery shopping, collecting prescriptions, transport to appointments and other errands. The request form lists the available categories.</p></div></div>
      <div class="faq-item"><button class="faq-q" type="button">How are volunteers matched to requests? <i class="fa-solid fa-plus" aria-hidden="true"></i></button><div class="faq-a"><p>Volunteers browse open requests in the Task Centre and accept the ones they can do. One volunteer takes each request.</p></div></div>
      <div class="faq-item"><button class="faq-q" type="button">How can I ask a question or raise a concern? <i class="fa-solid fa-plus" aria-hidden="true"></i></button><div class="faq-a"><p>Use the <a href="contact.php" style="color:var(--gold-deep);font-weight:700">Contact page</a> to send us a message and we will read it.</p></div></div>
    </div>
  </div>
</section>

<section class="section" style="padding-top:0">
  <div class="container">
    <div class="mission-banner">
      <i class="fa-solid fa-hands-holding-child"></i>
      <div>
        <h3>Our Mission</h3>
        <p>Our mission is simple: to make it easy for people to give and get help within their local community. We believe that small acts of kindness can create a big impact.</p>
      </div>
    </div>
  </div>
</section>

<section class="section">
  <div class="container">
    <div class="section-title reveal">
      <span class="eyebrow">WHAT WE DO</span>
      <h2>Connecting people who care</h2>
      <p>Community Assist exists to make asking for help, and offering it, feel completely natural.</p>
    </div>
    <div class="value-grid">
      <div class="value-card">
        <i class="fa-solid fa-people-arrows"></i>
        <h3>Connect</h3>
        <p>We connect people who need help with those who want to help.</p>
      </div>
      <div class="value-card">
        <i class="fa-solid fa-hand-holding-heart"></i>
        <h3>Support</h3>
        <p>We support volunteers and ensure safe, reliable interactions.</p>
      </div>
      <div class="value-card">
        <i class="fa-solid fa-building-shield"></i>
        <h3>Strengthen Communities</h3>
        <p>We work towards creating stronger, more compassionate communities.</p>
      </div>
      <div class="value-card">
        <i class="fa-solid fa-earth-africa"></i>
        <h3>Make an Impact</h3>
        <p>Together, we make a meaningful difference every day.</p>
      </div>
    </div>
  </div>
</section>

<section class="section" style="padding-top:0">
  <div class="container">
    <div class="section-title reveal">
      <span class="eyebrow">WHAT WE STAND FOR</span>
      <h2>Our values</h2>
      <p>These principles guide every feature we build and every rule we set.</p>
    </div>
    <div class="grid4">
      <div class="category">
        <div class="category-icon"><i class="fa-regular fa-heart"></i></div>
        <h3>Compassion</h3>
        <p>We care for each other and treat everyone with respect.</p>
      </div>
      <div class="category">
        <div class="category-icon"><i class="fa-solid fa-shield-heart"></i></div>
        <h3>Trust</h3>
        <p>We build trust through transparency and reliable actions.</p>
      </div>
      <div class="category">
        <div class="category-icon"><i class="fa-solid fa-people-group"></i></div>
        <h3>Inclusivity</h3>
        <p>We welcome everyone and celebrate diversity.</p>
      </div>
      <div class="category">
        <div class="category-icon"><i class="fa-solid fa-users"></i></div>
        <h3>Community</h3>
        <p>We believe strong communities make better lives.</p>
      </div>
    </div>
  </div>
</section>

<section class="section" style="padding-top:0">
  <div class="container">
    <div class="image-story-simple">
      <img src="<?php echo h(photo('about-2', 'https://images.unsplash.com/photo-1600880292203-757bb62b4baf?auto=format&fit=crop&w=900&q=88')); ?>" alt="A group of volunteers celebrating together, arms raised" onerror="this.onerror=null;this.src='images/illus-community.svg'">
      <div>
        <span class="eyebrow">MEET THE PEOPLE BEHIND IT</span>
        <h3>Our Team</h3>
        <p>We're a passionate team dedicated to building a platform that brings people together and makes helping easy and accessible for all.</p>
        <a class="btn btn-orange" href="volunteer.php">Join The Team <i class="fa-solid fa-arrow-right"></i></a>
      </div>
    </div>
  </div>
</section>

<section class="section" aria-labelledby="more-title">
  <div class="container">
    <div class="section-title reveal"><span class="eyebrow">Keep exploring</span><h2 id="more-title">Where would you like to go next?</h2><p>Everything you need to get started is a click away.</p></div>
    <div class="page-cards">
      <a class="page-card reveal" href="howitworks.php"><i class="fa-solid fa-diagram-project" aria-hidden="true"></i><h3>How It Works</h3><p class="for">Step by step</p><p>See exactly what happens after you submit or accept a request.</p></a>
      <a class="page-card reveal reveal-1" href="request.php"><i class="fa-solid fa-hand-holding-heart" aria-hidden="true"></i><h3>Request Help</h3><p class="for">For neighbours who need a hand</p><p>Tell us what you need and when.</p></a>
      <a class="page-card reveal reveal-2" href="volunteer.php"><i class="fa-regular fa-heart" aria-hidden="true"></i><h3>Volunteer</h3><p class="for">For people with time to give</p><p>Apply once and start picking up tasks.</p></a>
    </div>
  </div>
</section>

<div class="cta">
  <div class="cta-icon"><i class="fa-regular fa-heart"></i></div>
  <div class="cta-copy"><strong>Want to be part of the story?</strong><span>Sign up as a volunteer or requester and help us grow this community.</span></div>
  <a class="btn btn-orange" href="signup.php">Join Helping Hands <i class="fa-solid fa-arrow-right"></i></a>
</div>

</main>



<?php include __DIR__ . "/partials/footer.php"; ?>
</body>
</html>
