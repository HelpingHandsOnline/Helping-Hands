<?php
// Streams a volunteer's private ID document to administrators only.
require __DIR__ . '/config.php';
require_admin();
$uid = (int)($_GET['uid'] ?? 0);
$q = $pdo->prepare('SELECT id_document FROM volunteers WHERE user_id=? AND verification_status="Pending"');
$q->execute([$uid]);
$name = basename((string)$q->fetchColumn());
$path = __DIR__ . '/uploads/ids/' . $name;
if ($name === '' || !is_file($path)) { http_response_code(404); exit('Document not found.'); }
$mime = (new finfo(FILEINFO_MIME_TYPE))->file($path);
header('Content-Type: ' . $mime);
header('Content-Disposition: inline; filename="id-document"');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, no-store');
readfile($path);
