<?php
require __DIR__ . "/config.php"; $activePage = "home";
$live = ["members" => 0, "volunteers" => 0, "requests" => 0, "completed" => 0];
try {
    $live["members"]    = (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    $live["volunteers"] = (int)$pdo->query("SELECT COUNT(*) FROM volunteers WHERE status='Active'")->fetchColumn();
    $live["requests"]   = (int)$pdo->query("SELECT COUNT(*) FROM requests")->fetchColumn();
    $live["completed"]  = (int)$pdo->query("SELECT COUNT(*) FROM requests WHERE status='Completed'")->fetchColumn();
} catch (Throwable $e) { /* stats simply fall back to the static facts below */ }
$showLive = $live["members"] >= 10;   // only show real counts once there is something worth showing
$heroPic = function (int $n): string {
    foreach (["jpg", "jpeg", "webp", "png"] as $ext) {
        if (is_file(__DIR__ . "/images/hero-$n.$ext")) return "images/hero-$n.$ext";   // drop your own photos in here
    }
    return "images/hero-$n.svg";
};
$heroVideo = function (int $n): array {
    foreach (["mp4" => "video/mp4", "webm" => "video/webm"] as $ext => $mime) {
        if (is_file(__DIR__ . "/images/hero-$n.$ext")) return ["images/hero-$n.$ext", $mime];   // optional short looping clip
    }
    return [];
};
$slides = [
  ["Neighbours helping <em>neighbours.</em>", "Need a hand with groceries, a prescription or a lift to an appointment? Or have time to spare? Helping Hands connects the two, simply, respectfully and close to home.", "A volunteer and a neighbour outside a home", "A volunteer chatting warmly with two older women while they knit and do crafts together"],
  ["Company that <em>brightens the day.</em>", "A friendly visit or an hour of companionship can mean as much as a lift or a grocery run. Volunteers share their time, not just their tasks.", "Neighbours sharing a friendly moment", "Three smiling people painting together at a table in a community art session"],
  ["Safe, simple and <em>close to home.</em>", "Your contact details are shared only after a volunteer accepts, and every volunteer gives an emergency contact.", "A shield with a check mark", "A young volunteer chatting with two smiling older women seated beside their walking frames"],
];
?>
<!doctype html>
<html lang="<?php echo h(current_lang()); ?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Helping Hands Community Assist | Neighbours Helping Neighbours</title>
<meta name="description" content="Helping Hands Community Assist connects neighbours who need help with neighbours who want to volunteer their time. Simple. Respectful. Local.">
<meta name="theme-color" content="#0b3329">
<meta property="og:type" content="website">
<meta property="og:title" content="Helping Hands Community Assist | Neighbours Helping Neighbours">
<meta property="og:description" content="Request help or volunteer your time. Simple, respectful and local.">
<meta property="og:image" content="logo.png">
<meta property="og:site_name" content="Helping Hands Community Assist">
<meta name="twitter:card" content="summary">
<link rel="icon" href="logo.png"><link rel="manifest" href="manifest.webmanifest"><meta name="theme-color" content="#0b3329">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,600;0,700;1,600&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<link rel="stylesheet" href="common.css?v=5"><link rel="stylesheet" href="v5.css?v=5">
<link rel="stylesheet" href="home.css?v=5">
<link rel="stylesheet" href="polish.css?v=1">
</head>
<body>
<a class="skip-link" href="#main">Skip to content</a>

<?php include __DIR__ . "/partials/header.php"; ?>

<main id="main">

<section class="hero-slider" id="heroSlider" aria-roledescription="carousel" aria-label="Helping Hands highlights">
  <?php foreach ($slides as $i => $sl): $hasPhoto = substr($heroPic($i + 1), -4) !== ".svg"; ?>
  <div class="hs-slide<?php echo $i === 0 ? " is-active" : ""; ?><?php echo $hasPhoto ? " has-photo" : ""; ?>" role="group" aria-roledescription="slide" aria-label="<?php echo $i + 1; ?> of <?php echo count($slides); ?>"<?php echo $i === 0 ? "" : ' aria-hidden="true"'; ?>>
    <?php $pic = $heroPic($i + 1); $isPhoto = substr($pic, -4) !== ".svg"; $vid = $heroVideo($i + 1); $alt = $isPhoto ? $sl[3] : $sl[2]; ?>
    <?php if ($vid): ?>
    <video class="hs-img hs-video" muted loop playsinline preload="none" poster="<?php echo h($pic); ?>" aria-label="<?php echo h($alt); ?>"><source src="<?php echo h($vid[0]); ?>" type="<?php echo h($vid[1]); ?>"></video>
    <?php else: ?>
    <img class="hs-img" src="<?php echo h($pic); ?>" alt="<?php echo h($alt); ?>" width="1600" height="760"<?php echo $i === 0 ? ' fetchpriority="high"' : ' loading="lazy"'; ?>>
    <?php endif; ?>
    <div class="hs-shade"></div>
    <div class="container hs-content">
      <span class="hs-eyebrow"><?php echo $i === 0 ? "Community Assist" : "Helping Hands"; ?></span>
      <<?php echo $i === 0 ? "h1" : "h2"; ?> class="hs-title"><?php echo $sl[0]; ?></<?php echo $i === 0 ? "h1" : "h2"; ?>>
      <p class="hs-text"><?php echo h($sl[1]); ?></p>
      <div class="hero-actions">
        <a class="btn btn-orange" href="request.php"><i class="fa-solid fa-hand-holding-heart" aria-hidden="true"></i> Request help</a>
        <a class="btn btn-outline" href="volunteer.php"><i class="fa-regular fa-heart" aria-hidden="true"></i> Become a volunteer</a>
      </div>
    </div>
  </div>
  <?php endforeach; ?>
  <a class="hs-card" href="volunteer.php">
    <span class="hs-card-icon"><i class="fa-solid fa-people-group" aria-hidden="true"></i></span>
    <span><strong>Join as a volunteer</strong><small>Give an hour and brighten a neighbour's day.</small></span>
    <i class="fa-solid fa-arrow-right" aria-hidden="true"></i>
  </a>
  <div class="hs-controls">
    <div class="hs-dots" role="tablist" aria-label="Choose slide">
      <?php foreach ($slides as $i => $sl): ?><button type="button" class="hs-dot<?php echo $i === 0 ? " is-active" : ""; ?>" data-i="<?php echo $i; ?>" aria-label="Go to slide <?php echo $i + 1; ?>"></button><?php endforeach; ?>
    </div>
  </div>
</section>

<section class="section intro-stats" aria-labelledby="intro-title">
  <div class="container">
    <div class="intro-grid">
      <span class="eyebrow reveal">About Helping Hands</span>
      <p class="intro-text reveal" id="intro-title">From a lift to the pharmacy to a bag of shopping at the door, we turn <strong>small everyday favours</strong> into a stronger, kinder neighbourhood where nobody has to manage alone.</p>
    </div>
    <div class="stat-row reveal">
      <?php if ($showLive): ?>
        <div class="stat-box"><strong data-count="<?php echo $live["members"]; ?>"><?php echo $live["members"]; ?></strong><small>Community members</small></div>
        <div class="stat-box"><strong data-count="<?php echo $live["volunteers"]; ?>"><?php echo $live["volunteers"]; ?></strong><small>Active volunteers</small></div>
        <div class="stat-box"><strong data-count="<?php echo $live["requests"]; ?>"><?php echo $live["requests"]; ?></strong><small>Requests made</small></div>
        <div class="stat-box"><strong data-count="<?php echo $live["completed"]; ?>"><?php echo $live["completed"]; ?></strong><small>Tasks completed</small></div>
      <?php else: ?>
        <div class="stat-box"><strong>4</strong><small>Simple steps from request to done</small></div>
        <div class="stat-box"><strong>4</strong><small>Kinds of everyday help</small></div>
        <div class="stat-box"><strong>1</strong><small>Volunteer per request</small></div>
        <div class="stat-box"><strong>1</strong><small>Free account for asking and giving</small></div>
      <?php endif; ?>
    </div>
    <p class="stat-note"><?php echo $showLive ? "These figures are counted live from our community." : "Community figures will appear here as our neighbourhood grows."; ?></p>
    <div class="feature-trio">
      <article class="trio-card tone-blue reveal reveal-1"><i class="fa-solid fa-cart-shopping" aria-hidden="true"></i><h3>Practical help</h3><p>Groceries, prescriptions, lifts and errands, handled by people who live nearby.</p><a href="request.php" class="pill">Request help</a></article>
      <article class="trio-card tone-dark reveal reveal-2"><img src="images/illus-community.svg" alt="" width="640" height="440" loading="lazy"><div class="trio-over"><h3>Rooted in the neighbourhood</h3><p>Local people helping local people.</p></div></article>
      <article class="trio-card tone-green reveal reveal-3"><i class="fa-solid fa-shield-heart" aria-hidden="true"></i><h3>Safe by design</h3><p>Details are shared only after a volunteer accepts, and volunteers give an emergency contact.</p><a href="howitworks.php" class="pill">How it works</a></article>
    </div>
  </div>
</section>

<section class="section" aria-labelledby="how-title">
  <div class="container">
    <div class="section-title reveal">
      <span class="eyebrow">Simple by design</span>
      <h2 id="how-title">How it works</h2>
      <p>Four steps connect a request with the right person, safely and quickly.</p>
    </div>
    <div class="icon-steps">
      <div class="icon-step">
        <span class="step-badge" aria-hidden="true">1</span>
        <div class="step-icon"><i class="fa-solid fa-pen-to-square" aria-hidden="true"></i></div>
        <h3>Submit a request</h3>
        <p>Tell us what help you need, where and when.</p>
      </div>
      <div class="icon-arrow" aria-hidden="true"><i class="fa-solid fa-arrow-right"></i></div>
      <div class="icon-step">
        <span class="step-badge" aria-hidden="true">2</span>
        <div class="step-icon"><i class="fa-solid fa-people-group" aria-hidden="true"></i></div>
        <h3>A volunteer accepts</h3>
        <p>A local volunteer chooses to take it on.</p>
      </div>
      <div class="icon-arrow" aria-hidden="true"><i class="fa-solid fa-arrow-right"></i></div>
      <div class="icon-step">
        <span class="step-badge" aria-hidden="true">3</span>
        <div class="step-icon"><i class="fa-solid fa-location-dot" aria-hidden="true"></i></div>
        <h3>Get connected</h3>
        <p>Contact details are shared once the request is accepted.</p>
      </div>
      <div class="icon-arrow" aria-hidden="true"><i class="fa-solid fa-arrow-right"></i></div>
      <div class="icon-step">
        <span class="step-badge" aria-hidden="true">4</span>
        <div class="step-icon"><i class="fa-solid fa-circle-check" aria-hidden="true"></i></div>
        <h3>Task completed</h3>
        <p>The volunteer marks the task complete and it is recorded.</p>
      </div>
    </div>
    <p class="center-link"><a class="link-arrow" href="howitworks.php">Read the full walkthrough <i class="fa-solid fa-arrow-right" aria-hidden="true"></i></a></p>
  </div>
</section>

<section class="section tint" aria-labelledby="cat-title">
  <div class="container">
    <div class="section-title reveal">
      <span class="eyebrow">What we help with</span>
      <h2 id="cat-title">Everyday help, close to home</h2>
      <p>These are the kinds of requests neighbours can ask for.</p>
    </div>
    <div class="grid4">
      <a class="category reveal reveal-1" href="request.php">
        <div class="category-icon"><i class="fa-solid fa-cart-shopping" aria-hidden="true"></i></div>
        <h3>Grocery shopping</h3>
        <p>Help buying groceries and essential items.</p>
        <span class="link">Request this <i class="fa-solid fa-arrow-right" aria-hidden="true"></i></span>
      </a>
      <a class="category reveal reveal-2" href="request.php">
        <div class="category-icon"><i class="fa-solid fa-prescription-bottle-medical" aria-hidden="true"></i></div>
        <h3>Prescription collection</h3>
        <p>Collecting prescriptions from the pharmacy.</p>
        <span class="link">Request this <i class="fa-solid fa-arrow-right" aria-hidden="true"></i></span>
      </a>
      <a class="category reveal reveal-3" href="request.php">
        <div class="category-icon"><i class="fa-solid fa-car-side" aria-hidden="true"></i></div>
        <h3>Medical transport</h3>
        <p>A lift to and from medical appointments.</p>
        <span class="link">Request this <i class="fa-solid fa-arrow-right" aria-hidden="true"></i></span>
      </a>
      <a class="category reveal reveal-4" href="request.php">
        <div class="category-icon"><i class="fa-solid fa-clipboard-list" aria-hidden="true"></i></div>
        <h3>Other tasks</h3>
        <p>Errands, odd jobs and other daily tasks.</p>
        <span class="link">Request this <i class="fa-solid fa-arrow-right" aria-hidden="true"></i></span>
      </a>
    </div>
  </div>
</section>

<section class="section" aria-labelledby="who-title">
  <div class="container">
    <div class="section-title reveal">
      <span class="eyebrow">Who it is for</span>
      <h2 id="who-title">Two ways to take part</h2>
      <p>Create one account and use Helping Hands as a requester, a volunteer, or both.</p>
    </div>
    <div class="who-grid">
      <article class="panel who-card reveal">
        <div class="category-icon" style="margin:0 0 14px"><i class="fa-solid fa-hand-holding-heart" aria-hidden="true"></i></div>
        <h3>If you need a hand</h3>
        <ul class="feature-list">
          <li>Describe the help you need and when you need it</li>
          <li>Track your request from pending to completed</li>
          <li>Choose how you would like to be contacted</li>
        </ul>
        <a class="btn btn-orange" href="request.php">Request help</a>
      </article>
      <article class="panel who-card reveal reveal-1">
        <div class="category-icon" style="margin:0 0 14px"><i class="fa-regular fa-heart" aria-hidden="true"></i></div>
        <h3>If you can lend a hand</h3>
        <ul class="feature-list">
          <li>Apply once, with your areas, availability and an emergency contact</li>
          <li>Browse open requests in the Task Centre</li>
          <li>Accept what suits your schedule and mark it complete</li>
        </ul>
        <a class="btn btn-ghost" href="volunteer.php">Become a volunteer</a>
      </article>
    </div>
  </div>
</section>

<section class="section" aria-labelledby="about-title">
  <div class="container about-split">
    <div class="about-art reveal"><img src="images/illus-community.svg" alt="Illustration of neighbours' homes with a heart above them" width="640" height="440" loading="lazy"></div>
    <div class="reveal reveal-1">
      <span class="eyebrow">Our approach</span>
      <h2 id="about-title">Local help, arranged with care</h2>
      <p class="lead">Helping Hands is a simple way for neighbours to help neighbours. People who need support post a request, and local volunteers choose the tasks they are able to do.</p>
      <ul class="feature-list">
        <li><span><strong>Respectful.</strong> You decide what help you need and how you would like to be contacted.</span></li>
        <li><span><strong>Local.</strong> Requests are about everyday tasks close to home, such as shopping, prescriptions and lifts.</span></li>
        <li><span><strong>Simple.</strong> One account lets you ask for help, offer help, or do both.</span></li>
      </ul>
      <a class="btn btn-ghost" href="about.php">More about us</a>
    </div>
  </div>
</section>

<section class="section tint" aria-labelledby="safe-title">
  <div class="container">
    <div class="section-title reveal">
      <span class="eyebrow">Safety and privacy</span>
      <h2 id="safe-title">Built with care for everyone involved</h2>
      <p>These are the safeguards built into how the site works today.</p>
    </div>
    <div class="grid4">
      <div class="value-card reveal reveal-1"><i class="fa-solid fa-lock" aria-hidden="true"></i><h3>Details shared after acceptance</h3><p>Your contact details are shared only once a volunteer accepts your request.</p></div>
      <div class="value-card reveal reveal-2"><i class="fa-solid fa-id-card" aria-hidden="true"></i><h3>Emergency contact</h3><p>Every volunteer application includes an emergency contact name and number.</p></div>
      <div class="value-card reveal reveal-3"><i class="fa-solid fa-user-check" aria-hidden="true"></i><h3>One volunteer per request</h3><p>A request is taken by a single volunteer, so there is never any confusion about who is coming.</p></div>
      <div class="value-card reveal reveal-4"><i class="fa-solid fa-key" aria-hidden="true"></i><h3>Protected accounts</h3><p>Passwords are stored in scrambled (hashed) form, and forms are protected against forgery.</p></div>
    </div>
    <p class="notice"><i class="fa-solid fa-triangle-exclamation" aria-hidden="true"></i> Helping Hands is not an emergency service. In an emergency, contact your local emergency services immediately.</p>
  </div>
</section>

<section class="section" aria-labelledby="pages-title">
  <div class="container">
    <div class="section-title reveal">
      <span class="eyebrow">Find your way around</span>
      <h2 id="pages-title">Which page is right for you?</h2>
      <p>Each page is written for a particular visitor. Start with the one that sounds like you.</p>
    </div>
    <div class="page-cards">
      <a class="page-card reveal" href="request.php"><i class="fa-solid fa-hand-holding-heart" aria-hidden="true"></i><h3>Request Help</h3><p class="for">For neighbours who need a hand</p><p>Describe the task, choose a date and time, and let a volunteer take it on.</p></a>
      <a class="page-card reveal reveal-1" href="volunteer.php"><i class="fa-regular fa-heart" aria-hidden="true"></i><h3>Volunteer</h3><p class="for">For people with time to give</p><p>Share your areas, availability and skills, then pick up requests that suit you.</p></a>
      <a class="page-card reveal reveal-2" href="howitworks.php"><i class="fa-solid fa-diagram-project" aria-hidden="true"></i><h3>How It Works</h3><p class="for">For first-time visitors</p><p>See every step from request to completed task, and when details are shared.</p></a>
      <a class="page-card reveal" href="resources.php"><i class="fa-solid fa-book-open" aria-hidden="true"></i><h3>Resources</h3><p class="for">For requesters, volunteers and families</p><p>Guides, safety tips, FAQs and a way to subscribe for updates.</p></a>
      <a class="page-card reveal reveal-1" href="about.php"><i class="fa-solid fa-people-roof" aria-hidden="true"></i><h3>About</h3><p class="for">For anyone curious about us</p><p>Our mission, values and the thinking behind Helping Hands.</p></a>
      <a class="page-card reveal reveal-2" href="contact.php"><i class="fa-solid fa-envelope-open-text" aria-hidden="true"></i><h3>Contact</h3><p class="for">For questions and concerns</p><p>Send us a message and find our contact details.</p></a>
    </div>
  </div>
</section>

<section class="section tint" aria-labelledby="video-title">
  <div class="container video-section">
    <div class="video-copy">
      <span class="eyebrow">See it in action</span>
      <h2 id="video-title">What being part of this community looks like.</h2>
      <p>Every request becomes a real, human moment: a shared bag of groceries, a ride to an appointment, a familiar face checking in. Watch a short look at what everyday volunteering can achieve.</p>
      <a class="btn btn-orange" href="volunteer.php">Become a volunteer <i class="fa-solid fa-arrow-right" aria-hidden="true"></i></a>
    </div>
    <div class="video-embed">
      <iframe src="https://www.youtube-nocookie.com/embed/yocyWr-wSJY" title="A look at community volunteering in action" loading="lazy" referrerpolicy="strict-origin-when-cross-origin" allow="encrypted-media; picture-in-picture" allowfullscreen></iframe>
    </div>
  </div>
</section>

<section class="section" id="faq" aria-labelledby="faq-title">
  <div class="container">
    <div class="section-title reveal">
      <span class="eyebrow">Common questions</span>
      <h2 id="faq-title">Quick answers</h2>
    </div>
    <div class="faq-list">
      <div class="faq-item"><button class="faq-q" type="button">Do I need an account to ask for help? <i class="fa-solid fa-plus" aria-hidden="true"></i></button><div class="faq-a"><p>Yes. Creating an account lets you submit a request, follow its progress and be contacted once a volunteer accepts it.</p></div></div>
      <div class="faq-item"><button class="faq-q" type="button">When do volunteers see my contact details? <i class="fa-solid fa-plus" aria-hidden="true"></i></button><div class="faq-a"><p>Contact details are shared only after a volunteer accepts your request.</p></div></div>
      <div class="faq-item"><button class="faq-q" type="button">How do I become a volunteer? <i class="fa-solid fa-plus" aria-hidden="true"></i></button><div class="faq-a"><p>Create an account, then complete the volunteer application with your areas, availability, skills and an emergency contact. Once your profile is active, the Task Centre shows open requests.</p></div></div>
      <div class="faq-item"><button class="faq-q" type="button">Can I both ask for help and volunteer? <i class="fa-solid fa-plus" aria-hidden="true"></i></button><div class="faq-a"><p>Yes. One account can do both.</p></div></div>
      <div class="faq-item"><button class="faq-q" type="button">Is Helping Hands an emergency service? <i class="fa-solid fa-plus" aria-hidden="true"></i></button><div class="faq-a"><p>No. For emergencies, contact your local emergency services straight away.</p></div></div>
      <div class="faq-item"><button class="faq-q" type="button">I forgot my password. What can I do? <i class="fa-solid fa-plus" aria-hidden="true"></i></button><div class="faq-a"><p>Choose <a href="forgot-password.php" style="color:var(--gold-deep);font-weight:700">Forgot Password</a> on the log-in page and we will e-mail you a secure link to set a new password. It is valid for one hour. If nothing arrives, check your spam folder or <a href="contact.php" style="color:var(--gold-deep);font-weight:700">contact us</a>.</p></div></div>
    </div>
    <p class="center-link"><a class="link-arrow" href="resources.php#faq">More answers in Resources <i class="fa-solid fa-arrow-right" aria-hidden="true"></i></a></p>
  </div>
</section>

<div class="cta">
  <div class="cta-icon" aria-hidden="true"><i class="fa-solid fa-heart"></i></div>
  <div class="cta-copy"><strong>Stronger communities, together.</strong><span>Create a free account to request help or offer your time.</span></div>
  <a class="btn btn-orange" href="signup.php">Get started <i class="fa-solid fa-arrow-right" aria-hidden="true"></i></a>
</div>

</main>

<?php include __DIR__ . "/partials/footer.php"; ?>
</body>
</html>
