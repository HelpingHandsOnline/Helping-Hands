/* Helping Hands service worker.
   - Static files (CSS, JS, images, icons): cache-first so the app opens fast.
   - Pages: ALWAYS from the network (never cached), so private account pages are not stored on the device.
   - If the network is down, a friendly offline page is shown. */
const CACHE = 'hh-static-v8';
const PRECACHE = ['offline.html', 'logo.png', 'icon-192.png', 'icon-512.png', 'common.css?v=5', 'polish.css?v=1', 'common.js?v=8'];
self.addEventListener('install', e => { e.waitUntil(caches.open(CACHE).then(c => c.addAll(PRECACHE).catch(() => {})).then(() => self.skipWaiting())); });
self.addEventListener('activate', e => { e.waitUntil(caches.keys().then(k => Promise.all(k.filter(n => n !== CACHE).map(n => caches.delete(n)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', e => {
  const req = e.request, url = new URL(req.url);
  if (req.method !== 'GET' || url.origin !== location.origin) return;
  if (req.mode === 'navigate') { e.respondWith(fetch(req).catch(() => caches.match('offline.html'))); return; }
  if (/\.(css|js|png|jpg|jpeg|webp|svg|ico|woff2?)$/i.test(url.pathname)) {
    e.respondWith(caches.match(req).then(hit => hit || fetch(req).then(res => { const copy = res.clone(); caches.open(CACHE).then(c => c.put(req, copy)); return res; })));
  }
});
