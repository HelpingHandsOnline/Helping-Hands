<?php
require 'config.php'; require_login();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect('tasks.php');
verify_csrf();
$id = post_id('request_id');
$me = user();

$v = $pdo->prepare('SELECT status, verification_status FROM volunteers WHERE user_id=?');
$v->execute([$me['id']]);
$vp = $v->fetch();
if (!$vp || $vp['status'] !== 'Active') { flash('error', 'You need an active volunteer profile to accept tasks.'); redirect('tasks.php'); }
if (($vp['verification_status'] ?? '') !== 'Verified') { flash('error', 'Your volunteer verification must be approved before you can accept tasks.'); redirect('verify.php'); }

$q = $pdo->prepare("UPDATE requests SET volunteer_id=?, status='Accepted', accepted_at=NOW() WHERE id=? AND status='Pending' AND user_id<>?");
$q->execute([$me['id'], $id, $me['id']]);

if ($q->rowCount()) {
    $r = $pdo->prepare('SELECT user_id, category, location, preferred_date, preferred_time FROM requests WHERE id=?');
    $r->execute([$id]);
    $req = $r->fetch();
    if ($req) {
        notify((int)$req['user_id'], 'accepted', 'A volunteer accepted your request',
            $me['first_name'] . ' has accepted your ' . $req['category'] . ' request (' . $req['preferred_date'] . ' at ' . substr($req['preferred_time'], 0, 5) . ', ' . $req['location'] . '). '
            . 'You can reach them on ' . $me['phone'] . '.', 'tasks.php');
    }
    flash('success', 'Task accepted. The requester has been notified.');
} else {
    flash('error', 'That request is no longer available.');
}
redirect('tasks.php');
