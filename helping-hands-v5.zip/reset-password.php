<?php
require __DIR__ . "/config.php";
if (logged_in()) redirect("account.php");

$token = trim($_GET["token"] ?? $_POST["token"] ?? "");
$row = null;
if (preg_match('/^[a-f0-9]{64}$/', $token)) {
    $q = $pdo->prepare("SELECT pr.id, pr.user_id, u.first_name, u.email FROM password_resets pr JOIN users u ON u.id = pr.user_id
                        WHERE pr.token_hash = ? AND pr.used_at IS NULL AND pr.expires_at > NOW()");
    $q->execute([hash("sha256", $token)]);
    $row = $q->fetch() ?: null;
}

$errors = [];
if ($row && $_SERVER["REQUEST_METHOD"] === "POST") {
    verify_csrf();
    $pw = $_POST["password"] ?? "";
    $pw2 = $_POST["confirm"] ?? "";
    if (strlen($pw) < 8) $errors[] = "Password must be at least 8 characters.";
    if ($pw !== $pw2) $errors[] = "Passwords do not match.";
    if (!$errors) {
        $pdo->beginTransaction();
        $pdo->prepare("UPDATE users SET password_hash = ? WHERE id = ?")->execute([password_hash($pw, PASSWORD_DEFAULT), $row["user_id"]]);
        $pdo->prepare("UPDATE password_resets SET used_at = NOW() WHERE user_id = ? AND used_at IS NULL")->execute([$row["user_id"]]);
        $pdo->commit();
        notify((int)$row["user_id"], "security", "Your password was changed", "The password on your Helping Hands account was just changed. If this was not you, contact us straight away.", "contact.php");
        flash("success", "Your password has been changed. You can log in now.");
        redirect("login.php");
    }
}

page_start("Choose a New Password", ["auth-pages.css"], "", "Choose a new password for your Helping Hands account.");
?>
<div class="auth-solo">
  <div class="form-card">
    <?php if (!$row): ?>
      <h2>This link has expired</h2>
      <div class="alert-box warn">The reset link is invalid, has already been used, or is older than 1 hour. Reset links can only be used once.</div>
      <a class="btn btn-orange full" href="forgot-password.php">Request a new link</a>
    <?php else: ?>
      <h2>Choose a new password</h2>
      <p class="lead-sm">Hi <?php echo h($row["first_name"]); ?>, pick a password of at least 8 characters.</p>
      <?php if ($errors): ?><div class="form-errors"><?php echo implode("<br>", array_map("h", $errors)); ?></div><?php endif; ?>
      <form method="post" novalidate>
        <input type="hidden" name="csrf" value="<?php echo h(csrf_token()); ?>">
        <input type="hidden" name="token" value="<?php echo h($token); ?>">
        <div class="field">
          <label for="password">New password</label>
          <div class="input-icon"><i class="fa-solid fa-lock" aria-hidden="true"></i><input id="password" name="password" type="password" required minlength="8" autocomplete="new-password"><button type="button" class="reveal-toggle" data-target="password" aria-label="Show password"><i class="fa-regular fa-eye"></i></button></div>
        </div>
        <div class="field">
          <label for="confirm">Confirm new password</label>
          <div class="input-icon"><i class="fa-solid fa-lock" aria-hidden="true"></i><input id="confirm" name="confirm" type="password" required minlength="8" autocomplete="new-password"><button type="button" class="reveal-toggle" data-target="confirm" aria-label="Show password"><i class="fa-regular fa-eye"></i></button></div>
        </div>
        <button type="submit" class="btn btn-orange full">Save new password</button>
      </form>
    <?php endif; ?>
  </div>
</div>
<?php page_end(); ?>
