<?php
require 'config.php';
require_login('tasks');
$me = user();

$vq = $pdo->prepare('SELECT id, status, verification_status FROM volunteers WHERE user_id=?');
$vq->execute([$me['id']]);
$vp = $vq->fetch();
$isVolunteer = (bool)$vp;
$isActive = $isVolunteer && $vp['status'] === 'Active';
$isVerified = $isVolunteer && ($vp['verification_status'] ?? '') === 'Verified';

$categories = ['Grocery Shopping', 'Prescription Pickup', 'Medical Transport', 'Household Tasks', 'Companionship', 'Other'];

/* ---- filters for the open requests ---- */
$f = [
    'area'     => trim($_GET['area'] ?? ''),
    'category' => trim($_GET['category'] ?? ''),
    'from'     => trim($_GET['from'] ?? ''),
    'to'       => trim($_GET['to'] ?? ''),
];
$validDate = fn(string $d): bool => (bool)preg_match('/^\d{4}-\d{2}-\d{2}$/', $d) && checkdate((int)substr($d, 5, 2), (int)substr($d, 8, 2), (int)substr($d, 0, 4));
if ($f['category'] !== '' && !in_array($f['category'], $categories, true)) $f['category'] = '';
if ($f['from'] !== '' && !$validDate($f['from'])) $f['from'] = '';
if ($f['to'] !== '' && !$validDate($f['to'])) $f['to'] = '';
$filtered = $f['area'] !== '' || $f['category'] !== '' || $f['from'] !== '' || $f['to'] !== '';

$requests = [];
if ($isActive) {
    $sql = "SELECT r.*, u.first_name, u.last_name FROM requests r JOIN users u ON u.id = r.user_id
            WHERE r.status = 'Pending' AND r.user_id <> :me";
    $p = [':me' => $me['id']];
    if ($f['area'] !== '')     { $sql .= ' AND r.location LIKE :area'; $p[':area'] = '%' . addcslashes($f['area'], '%_\\') . '%'; }
    if ($f['category'] !== '') { $sql .= ' AND r.category = :cat';     $p[':cat'] = $f['category']; }
    if ($f['from'] !== '')     { $sql .= ' AND r.preferred_date >= :from'; $p[':from'] = $f['from']; }
    if ($f['to'] !== '')       { $sql .= ' AND r.preferred_date <= :to';   $p[':to'] = $f['to']; }
    $sql .= ' ORDER BY r.preferred_date ASC, r.preferred_time ASC LIMIT 200';
    $q = $pdo->prepare($sql);
    $q->execute($p);
    $requests = $q->fetchAll();
}

/* ---- tasks the volunteer accepted ---- */
$accepted = [];
if ($isVolunteer) {
    $q = $pdo->prepare("SELECT r.*, u.first_name, u.last_name, u.phone, rt.stars FROM requests r JOIN users u ON u.id = r.user_id
                        LEFT JOIN ratings rt ON rt.request_id = r.id WHERE r.volunteer_id = ? ORDER BY r.created_at DESC");
    $q->execute([$me['id']]);
    $accepted = $q->fetchAll();
}

/* ---- my own requests ---- */
$mine = $pdo->prepare("SELECT r.*, v.first_name vfirst, v.last_name vlast, rt.stars,
        (SELECT ROUND(AVG(stars),1) FROM ratings WHERE volunteer_id = r.volunteer_id) vavg,
        (SELECT COUNT(*) FROM ratings WHERE volunteer_id = r.volunteer_id) vcount
        FROM requests r LEFT JOIN users v ON v.id = r.volunteer_id LEFT JOIN ratings rt ON rt.request_id = r.id
        WHERE r.user_id = ? ORDER BY r.created_at DESC");
$mine->execute([$me['id']]);
$myRequests = $mine->fetchAll();
$myRating = $isVolunteer ? avg_rating((int)$me['id']) : [0.0, 0];

page_start('Task Centre', [], 'tasks');
$guide = ["who" => "Volunteers with an active, verified profile, and anyone who wants to follow the progress of their own help requests.",
          "what" => "Search open requests by area, category and date, accept tasks that suit you, mark them complete and manage your own requests.",
          "next" => [["My account", "account.php"], ["Request help", "request.php"], ["Contact us", "contact.php"]]];
include __DIR__ . '/partials/page-guide.php';
?>
<div class="container page-top">
  <span class="eyebrow">TASK CENTRE</span>
  <h1>Volunteer tasks &amp; requests</h1>
  <p>See available requests, accept suitable tasks and track the help you have given or received.</p>
</div>

<section class="section" style="padding-top:18px">
<div class="container stack">

<?php if (!$isVolunteer): ?>
  <div class="panel"><h3>Ready to volunteer?</h3><p>You haven't completed a volunteer application yet. Complete it to unlock open requests.</p><a class="btn primary" style="margin-top:12px" href="volunteer.php">Become a volunteer</a></div>
<?php elseif (!$isActive): ?>
  <div class="panel"><h3>Your volunteer profile is paused</h3><p>Update your volunteer application to reactivate it before accepting tasks.</p><a class="btn primary" style="margin-top:12px" href="volunteer.php#apply">Update profile</a></div>
<?php else: ?>
  <?php if (!$isVerified): ?>
    <div class="alert-box warn"><i class="fa-solid fa-shield-heart" aria-hidden="true"></i>
      <strong>Verification needed before you can accept tasks.</strong>
      <?php echo ($vp['verification_status'] ?? '') === 'Pending' ? 'Your ID and references are being reviewed. You can browse requests in the meantime.' : 'Upload your ID and two references so we can keep everyone safe.'; ?>
      <a href="verify.php" style="font-weight:800;text-decoration:underline">Go to verification</a>
    </div>
  <?php endif; ?>

  <div class="panel" id="open">
    <h3>Available requests</h3>
    <form class="filter-bar" method="get" action="tasks.php#open" role="search" aria-label="Filter open requests" style="margin-top:14px">
      <div class="field"><label for="f-area">Area</label><input id="f-area" name="area" value="<?php echo h($f['area']); ?>" placeholder="e.g. Observatory" maxlength="80"></div>
      <div class="field"><label for="f-cat">Category</label>
        <select id="f-cat" name="category"><option value="">All categories</option>
          <?php foreach ($categories as $c): ?><option<?php echo $f['category'] === $c ? ' selected' : ''; ?>><?php echo h($c); ?></option><?php endforeach; ?>
        </select></div>
      <div class="field"><label for="f-from">From date</label><input id="f-from" type="date" name="from" value="<?php echo h($f['from']); ?>"></div>
      <div class="field"><label for="f-to">To date</label><input id="f-to" type="date" name="to" value="<?php echo h($f['to']); ?>"></div>
      <div class="btns"><button class="btn primary" type="submit"><i class="fa-solid fa-magnifying-glass"></i> Search</button>
        <?php if ($filtered): ?><a class="btn btn-ghost" href="tasks.php#open">Clear</a><?php endif; ?></div>
    </form>
    <p class="result-count" role="status"><?php echo count($requests); ?> open request<?php echo count($requests) === 1 ? '' : 's'; ?><?php echo $filtered ? ' match your search' : ''; ?><?php echo count($requests) >= 200 ? ' (showing the first 200)' : ''; ?></p>

    <?php if (!$requests): ?>
      <div class="empty"><strong><?php echo $filtered ? 'Nothing matches those filters' : 'No pending requests right now'; ?></strong>
        <p class="muted"><?php echo $filtered ? 'Try a wider area, another category or a bigger date range.' : 'Check again later. New requests appear here as soon as they are submitted.'; ?></p></div>
    <?php else: ?>
      <div class="card-list">
      <?php foreach ($requests as $r): ?>
        <article class="item-card">
          <div>
            <h4><?php echo h($r['category']); ?></h4>
            <p class="meta"><i class="fa-solid fa-location-dot"></i> <?php echo h($r['location']); ?> &nbsp; <i class="fa-regular fa-calendar"></i> <?php echo h(date('D, d M Y', strtotime($r['preferred_date']))); ?> at <?php echo h(substr($r['preferred_time'], 0, 5)); ?></p>
            <p class="meta"><i class="fa-regular fa-user"></i> Requested by <?php echo h($r['first_name'] . ' ' . mb_substr($r['last_name'], 0, 1) . '.'); ?></p>
          </div>
          <div>
            <?php if ($isVerified): ?>
              <form method="post" action="accept_task.php"><input type="hidden" name="csrf" value="<?php echo h(csrf_token()); ?>"><input type="hidden" name="request_id" value="<?php echo (int)$r['id']; ?>"><button class="btn primary small">Accept task</button></form>
            <?php else: ?>
              <a class="btn btn-ghost small" href="verify.php">Verify to accept</a>
            <?php endif; ?>
          </div>
        </article>
      <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>

  <div class="panel">
    <h3>Tasks I accepted <?php if ($myRating[1] > 0): ?><span style="font-weight:500;font-size:14px;margin-left:8px">My rating: <?php echo stars_html($myRating[0], $myRating[1]); ?></span><?php endif; ?></h3>
    <?php if (!$accepted): ?><p class="muted" style="margin-top:8px">You have not accepted a task yet.</p><?php else: ?>
      <div class="card-list" style="margin-top:14px">
      <?php foreach ($accepted as $r): ?>
        <article class="item-card">
          <div>
            <h4><?php echo h($r['category']); ?> <?php echo status_pill($r['status']); ?></h4>
            <p class="meta"><i class="fa-solid fa-location-dot"></i> <?php echo h($r['location']); ?> &nbsp; <i class="fa-regular fa-calendar"></i> <?php echo h(date('d M Y', strtotime($r['preferred_date']))); ?> at <?php echo h(substr($r['preferred_time'], 0, 5)); ?></p>
            <?php if ($r['status'] !== 'Cancelled'): ?>
              <p class="meta"><i class="fa-regular fa-user"></i> <?php echo h($r['first_name'] . ' ' . $r['last_name']); ?> &nbsp; <i class="fa-solid fa-phone"></i> <a href="tel:<?php echo h(preg_replace('/[^\d+]/', '', $r['phone'])); ?>"><?php echo h($r['phone']); ?></a> (prefers: <?php echo h($r['contact_method']); ?>)</p>
            <?php endif; ?>
            <?php if ($r['stars']): ?><p class="meta">Rated <span class="stars"><?php echo str_repeat('★', (int)$r['stars']) . str_repeat('☆', 5 - (int)$r['stars']); ?></span></p><?php endif; ?>
            <?php if ($r['status'] === 'Cancelled'): ?><p class="meta">The requester cancelled this task<?php echo $r['cancel_reason'] ? ': ' . h($r['cancel_reason']) : '.'; ?></p><?php endif; ?>
          </div>
          <div>
            <?php if ($r['status'] === 'Accepted'): ?>
              <form method="post" action="complete_task.php"><input type="hidden" name="csrf" value="<?php echo h(csrf_token()); ?>"><input type="hidden" name="request_id" value="<?php echo (int)$r['id']; ?>"><button class="btn secondary small">Mark completed</button></form>
            <?php endif; ?>
          </div>
          <?php if ($r['notes'] && $r['status'] === 'Accepted'): ?><div class="note"><strong>Notes from the requester:</strong> <?php echo nl2br(h($r['notes'])); ?></div><?php endif; ?>
        </article>
      <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
<?php endif; ?>

  <div class="panel">
    <h3>My help requests</h3>
    <?php if (!$myRequests): ?>
      <p class="muted" style="margin-top:8px">You have not submitted a help request yet.</p><a class="btn primary small" style="margin-top:12px" href="request.php">Request help</a>
    <?php else: ?>
      <div class="card-list" style="margin-top:14px">
      <?php foreach ($myRequests as $r): $vname = trim(($r['vfirst'] ?? '') . ' ' . ($r['vlast'] ?? '')); ?>
        <article class="item-card">
          <div>
            <h4><?php echo h($r['category']); ?> <?php echo status_pill($r['status']); ?></h4>
            <p class="meta"><i class="fa-solid fa-location-dot"></i> <?php echo h($r['location']); ?> &nbsp; <i class="fa-regular fa-calendar"></i> <?php echo h(date('d M Y', strtotime($r['preferred_date']))); ?> at <?php echo h(substr($r['preferred_time'], 0, 5)); ?></p>
            <p class="meta"><i class="fa-solid fa-hand-holding-heart"></i> <?php echo $vname !== '' ? h($vname) . ' ' . stars_html((float)($r['vavg'] ?? 0), (int)($r['vcount'] ?? 0)) : 'No volunteer yet'; ?></p>
            <?php if ($r['stars']): ?><p class="meta">Your rating: <span class="stars"><?php echo str_repeat('★', (int)$r['stars']) . str_repeat('☆', 5 - (int)$r['stars']); ?></span></p><?php endif; ?>
          </div>
          <div class="row-actions">
            <?php if ($r['status'] === 'Pending'): ?><a class="btn btn-ghost small" href="edit_request.php?id=<?php echo (int)$r['id']; ?>"><i class="fa-solid fa-pen"></i> Edit</a><?php endif; ?>
            <?php if (in_array($r['status'], ['Pending', 'Accepted'], true)): ?>
              <form class="inline-form" method="post" action="cancel_request.php" data-confirm="Cancel this request? <?php echo $r['status'] === 'Accepted' ? 'Your volunteer will be told.' : ''; ?>"><input type="hidden" name="csrf" value="<?php echo h(csrf_token()); ?>"><input type="hidden" name="id" value="<?php echo (int)$r['id']; ?>"><button class="btn danger small"><i class="fa-solid fa-xmark"></i> Cancel</button></form>
            <?php endif; ?>
            <?php if ($r['status'] === 'Completed' && !$r['stars']): ?><a class="btn primary small" href="rate.php?request_id=<?php echo (int)$r['id']; ?>"><i class="fa-regular fa-star"></i> Rate volunteer</a><?php endif; ?>
          </div>
        </article>
      <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</div>
</section>
<?php page_end(); ?>
