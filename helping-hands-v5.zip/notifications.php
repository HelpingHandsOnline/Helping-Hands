<?php
require __DIR__ . "/config.php";
require_login("notifications");
$me = user();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    verify_csrf();
    $action = $_POST["action"] ?? "";
    if ($action === "prefs") {
        $pdo->prepare("UPDATE users SET notify_email=?, notify_sms=? WHERE id=?")->execute([isset($_POST["notify_email"]) ? 1 : 0, isset($_POST["notify_sms"]) ? 1 : 0, $me["id"]]);
        flash("success", "Your notification preferences were saved.");
    } elseif ($action === "clear") {
        $pdo->prepare("DELETE FROM notifications WHERE user_id=?")->execute([$me["id"]]);
        flash("success", "Notifications cleared.");
    }
    redirect("notifications.php");
}

$q = $pdo->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC, id DESC LIMIT 60");
$q->execute([$me["id"]]);
$items = $q->fetchAll();
$pdo->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ? AND is_read = 0")->execute([$me["id"]]);

$icons = ["accepted" => "fa-handshake-angle", "completed" => "fa-circle-check", "cancelled" => "fa-ban", "rating" => "fa-star", "verification" => "fa-shield-heart", "security" => "fa-lock"];
$smsOn = (setting("sms", [])["provider"] ?? "") === "twilio";

page_start("Notifications", [], "");
?>
<div class="container page-top">
  <span class="eyebrow">UPDATES</span>
  <h1>Notifications</h1>
  <p>When a request is accepted, completed or cancelled, you will see it here. We can also e-mail you<?php echo $smsOn ? " or send an SMS" : ""; ?>.</p>
</div>
<section class="section" style="padding-top:18px">
  <div class="container wrap-wide notif-layout">
    <div>
      <?php if (!$items): ?>
        <div class="empty"><strong>No notifications yet</strong><p class="muted">Updates about your requests and tasks will appear here.</p></div>
      <?php else: ?>
        <div class="notif-list">
        <?php foreach ($items as $n): ?>
          <article class="notif<?php echo $n["is_read"] ? "" : " unread"; ?>">
            <div class="ico"><i class="fa-solid <?php echo h($icons[$n["type"]] ?? "fa-bell"); ?>" aria-hidden="true"></i></div>
            <div>
              <h4><?php echo h($n["title"]); ?></h4>
              <p><?php echo nl2br(h($n["body"])); ?></p>
              <time datetime="<?php echo h($n["created_at"]); ?>"><?php echo h(date("d M Y, H:i", strtotime($n["created_at"]))); ?></time>
              <?php if ($n["link"]): ?> &nbsp; <a class="go" href="<?php echo h($n["link"]); ?>">Open <i class="fa-solid fa-arrow-right"></i></a><?php endif; ?>
            </div>
          </article>
        <?php endforeach; ?>
        </div>
        <form method="post" class="mt" data-confirm="Delete all your notifications?"><input type="hidden" name="csrf" value="<?php echo h(csrf_token()); ?>"><input type="hidden" name="action" value="clear"><button class="btn btn-ghost small">Clear all</button></form>
      <?php endif; ?>
    </div>
    <aside class="form-card">
      <h2 style="font-size:20px">How should we reach you?</h2>
      <p class="lead-sm">In-app notifications are always on. Choose what else you would like.</p>
      <form method="post">
        <input type="hidden" name="csrf" value="<?php echo h(csrf_token()); ?>"><input type="hidden" name="action" value="prefs">
        <div class="check-row"><input id="ne" type="checkbox" name="notify_email" <?php echo $me["notify_email"] ? "checked" : ""; ?>><label for="ne">E-mail me at <strong><?php echo h($me["email"]); ?></strong></label></div>
        <div class="check-row"><input id="ns" type="checkbox" name="notify_sms" <?php echo $me["notify_sms"] ? "checked" : ""; ?> <?php echo $smsOn ? "" : "disabled"; ?>><label for="ns">SMS me on <strong><?php echo h($me["phone"]); ?></strong><?php echo $smsOn ? "" : " <span class=\"muted-small\">(SMS is not switched on for this site yet)</span>"; ?></label></div>
        <button class="btn btn-orange small" type="submit">Save preferences</button>
      </form>
    </aside>
  </div>
</section>
<?php page_end(); ?>
