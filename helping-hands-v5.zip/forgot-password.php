<?php
require __DIR__ . "/config.php";
if (logged_in()) redirect("account.php");

$errors = [];
$sent = false;
$email = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    verify_csrf();
    $email = trim($_POST["email"] ?? "");
    if ($email === "" || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Please enter the e-mail address you signed up with.";
    } else {
        // Same answer whether or not the account exists, so nobody can probe which e-mails are registered.
        $sent = true;
        $q = $pdo->prepare("SELECT id, first_name, email FROM users WHERE email = ?");
        $q->execute([$email]);
        $u = $q->fetch();
        if ($u) {
            $recent = $pdo->prepare("SELECT COUNT(*) FROM password_resets WHERE user_id = ? AND created_at > (NOW() - INTERVAL 1 HOUR)");
            $recent->execute([$u["id"]]);
            if ((int)$recent->fetchColumn() < 3) {                       // at most 3 requests per hour
                $token = bin2hex(random_bytes(32));
                $pdo->prepare("INSERT INTO password_resets (user_id, token_hash, expires_at) VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 1 HOUR))")
                    ->execute([$u["id"], hash("sha256", $token)]);
                $link = base_url() . "/reset-password.php?token=" . $token;
                $body = "<p>Hi " . h($u["first_name"]) . ",</p><p>We received a request to reset the password on your Helping Hands account. "
                      . "This link works for <strong>1 hour</strong> and can be used once.</p>"
                      . "<p style=\"font-size:13px;color:#55675f\">If you did not ask for this, you can safely ignore this e-mail. Your password will not change.</p>";
                send_mail($u["email"], "Reset your Helping Hands password", email_wrap("Reset your password", $body, $link, "Choose a new password"), (int)$u["id"]);
            }
        }
    }
}

page_start("Reset Your Password", ["auth-pages.css"], "", "Reset the password for your Helping Hands account.");
?>
<div class="auth-solo">
  <div class="form-card">
    <h2>Forgot your password?</h2>
    <?php if ($sent): ?>
      <div class="alert-box good" role="status"><i class="fa-solid fa-circle-check" aria-hidden="true"></i> If an account exists for <strong><?php echo h($email); ?></strong>, we have sent a link to reset the password. It is valid for 1 hour.</div>
      <p class="muted-small">Nothing in your inbox after a few minutes? Check your spam folder, or <a class="link-orange" href="contact.php">contact us</a> and we will help you regain access.</p>
      <a class="btn btn-orange full" href="login.php">Back to log in</a>
    <?php else: ?>
      <p class="lead-sm">Enter the e-mail address on your account and we will send you a secure link to choose a new password.</p>
      <?php if ($errors): ?><div class="form-errors"><?php echo implode("<br>", array_map("h", $errors)); ?></div><?php endif; ?>
      <form method="post" novalidate>
        <input type="hidden" name="csrf" value="<?php echo h(csrf_token()); ?>">
        <div class="field">
          <label for="email">E-mail address</label>
          <div class="input-icon"><i class="fa-regular fa-envelope" aria-hidden="true"></i><input id="email" name="email" type="email" required autocomplete="email" value="<?php echo h($email); ?>" placeholder="you@example.com"></div>
        </div>
        <button type="submit" class="btn btn-orange full">Send reset link</button>
      </form>
      <p class="switch-line">Remembered it? <a class="link-orange" href="login.php">Log in</a></p>
    <?php endif; ?>
  </div>
</div>
<?php page_end(); ?>
