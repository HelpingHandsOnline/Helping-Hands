# Helping Hands redesign — what changed

## v5.2 — Readability and copy fixes
- Headings on the log-in / sign-up side panel and the Contact "Get in Touch" panel were dark-on-dark; now white.
- Footer links stack properly on phones; faint helper text and tags darkened; "Send Message" button text enlarged.
- Removed outdated "password reset not available yet" text (Contact page and FAQ) and pointed to Forgot Password.

## v5.1 — Responsive polish (phones, tablets, laptops, desktops)
- polish.css (loaded last): even side gutters, fluid section spacing, safe grids, 44px touch targets, no sideways scroll, iPhone no-zoom form fields.
- Fixed: Volunteer application form and Account dashboard did not collapse to one column on phones/tablets (inline styles).
- Language switcher moved to the top bar so it works on every screen size; notification bell and Install button added to the mobile header.
- Header no longer overflows on small laptops; Request stepper fits 360px phones; hero crops to show people on phones.
- Social icons only appear when they have a real address.

## v5 — Future improvements implemented (see UPGRADE-TO-V5.md)
- Password reset by e-mail (SMTP): forgot-password.php, reset-password.php; hashed one-hour single-use tokens, 3 requests/hour limit.
- Volunteer verification: verify.php (ID upload + 2 references), admin approval, only verified volunteers can accept tasks, ID file deleted after decision.
- Notifications: bell + notifications.php, e-mail on accept / complete / cancel / rating / verification, optional SMS (Twilio).
- Administrator dashboard: admin.php (overview, verification queue, users, requests, messages, e-mail log).
- Edit and cancel requests: edit_request.php, cancel_request.php (volunteer is notified).
- Ratings and feedback: rate.php, average rating shown to requesters and on the volunteer's account.
- Task Centre search and filter by area, category and date range (tasks.php).
- Contact details now live in site-settings.php; stock photo hotlinks replaced by drop-in slots in images/photos/.
- Progressive web app (manifest, service worker, offline page, install button) and English / Afrikaans / isiXhosa interface switcher.

Rebuilt: common.css (Forest & Gold system), partials/header.php, partials/footer.php, common.js, index.php, home.css.
Edited: fonts on all pages (Playfair Display + Plus Jakarta Sans); invented stats/claims removed (resources, volunteer, howitworks);
forgot-password.php no longer pretends to email a reset link; fake "Continue with Google" button removed from login.php.

## You must replace before going live
- contact.php: phone (012) 345 6790, "123 Community Way, Yourtown", the helpinghands.org emails, office hours are placeholders.
- Hero/other photos are Unsplash hotlinks (index, about, volunteer, resources, contact, request): download them into an /images folder and point the src there.
- The YouTube video on the homepage: confirm it is content you may show.
- No social links in the footer until you have real accounts.
- (Done in v5) Password reset by e-mail.

## Round 4
- Full-width slideshow hero on the homepage (4 slides, arrows, dots, pause, keyboard), live community stats from the database (shown once there are 10+ members), count-up animation. Drop your own photos in images/hero-1.jpg ... hero-4.jpg and they replace the illustrations automatically.

## Round 3
- Top bar, auto-hiding header (hides on scroll down, returns on scroll up), new footer with social icons, long About page, detailed text on every page, image animations. The invented "Meet the team" (names and stock photos) was removed from About.

## Round 2
- Password eye icon now sits inside the box (auth-pages.css); role dropdown restyled.
- "Who this page is for / What you can do / Where to go next" strip on About, How It Works, Request, Volunteer, Resources, Contact, Task Centre, Account.
- Homepage: Our approach, Safety and privacy, Which page is right for you, and FAQ sections.
- images/: four local illustrations (no hotlinking needed). The hero falls back to one if the Unsplash photo fails.
- social-links.php: paste your real page addresses; empty ones are hidden from the footer.
- config.php is NOT in the update zip, so your database details are not overwritten.
