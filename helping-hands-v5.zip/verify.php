<?php
require __DIR__ . "/config.php";
require_login("verify");
$me = user();

$q = $pdo->prepare("SELECT * FROM volunteers WHERE user_id = ?");
$q->execute([$me["id"]]);
$vol = $q->fetch();
if (!$vol) { flash("error", "Please complete the volunteer application first."); redirect("volunteer.php#apply"); }

$status = $vol["verification_status"] ?? "Unverified";
$errors = [];
$old = ["ref1_name" => "", "ref1_phone" => "", "ref1_relationship" => "", "ref2_name" => "", "ref2_phone" => "", "ref2_relationship" => ""];

if ($_SERVER["REQUEST_METHOD"] === "POST" && in_array($status, ["Unverified", "Rejected"], true)) {
    verify_csrf();
    foreach ($old as $k => $_) $old[$k] = trim($_POST[$k] ?? "");
    foreach ([1, 2] as $n) {
        if (mb_strlen($old["ref{$n}_name"]) < 2) $errors[] = "Please give the full name of reference $n.";
        if (strlen(preg_replace('/\D/', '', $old["ref{$n}_phone"])) < 9) $errors[] = "Please give a valid phone number for reference $n.";
        if ($old["ref{$n}_relationship"] === "") $errors[] = "Please say how reference $n knows you.";
    }
    $p1 = preg_replace('/\D/', '', $old["ref1_phone"]); $p2 = preg_replace('/\D/', '', $old["ref2_phone"]);
    $mine = preg_replace('/\D/', '', (string)$me["phone"]);
    if ($p1 !== "" && $p1 === $p2) $errors[] = "The two references must be different people.";
    if ($p1 !== "" && ($p1 === $mine || $p2 === $mine)) $errors[] = "A reference cannot be your own phone number.";
    if (!isset($_POST["consent"])) $errors[] = "Please confirm that the information is true and that we may contact your references.";

    $stored = null;
    if (!$errors) {
        [$stored, $uploadError] = save_private_upload($_FILES["id_doc"] ?? [], "uploads/ids");
        if ($uploadError) $errors[] = $uploadError;
    }
    if (!$errors && $stored) {
        if (!empty($vol["id_document"])) @unlink(__DIR__ . "/uploads/ids/" . basename($vol["id_document"]));
        $pdo->prepare("UPDATE volunteers SET verification_status='Pending', id_document=?, ref1_name=?, ref1_phone=?, ref1_relationship=?,
                       ref2_name=?, ref2_phone=?, ref2_relationship=?, verification_submitted_at=NOW(), verification_note=NULL WHERE user_id=?")
            ->execute([$stored, $old["ref1_name"], $old["ref1_phone"], $old["ref1_relationship"], $old["ref2_name"], $old["ref2_phone"], $old["ref2_relationship"], $me["id"]]);
        notify_admins("verification", "New volunteer verification to review", $me["first_name"] . " " . $me["last_name"] . " submitted an ID and two references.", "admin.php?tab=verification");
        notify((int)$me["id"], "verification", "Verification received", "Thanks, we have received your ID and references. A coordinator will review them and you will be notified of the result.", "verify.php");
        flash("success", "Verification submitted. We will notify you once it has been reviewed.");
        redirect("verify.php");
    }
}

page_start("Volunteer Verification", [], "volunteer");
?>
<div class="container page-top">
  <span class="eyebrow">VOLUNTEER SAFETY</span>
  <h1>Verify your identity</h1>
  <p>Helping Hands serves people who may be vulnerable, so every volunteer is checked before they can accept a task. It takes about five minutes.</p>
</div>

<section class="section" style="padding-top:20px">
  <div class="container wrap-narrow stack">
    <?php if ($status === "Verified"): ?>
      <div class="form-card">
        <h2><i class="fa-solid fa-shield-heart" aria-hidden="true" style="color:var(--gold-deep)"></i> You are a verified volunteer</h2>
        <p class="lead-sm">Verified on <?php echo h(date("d M Y", strtotime($vol["verified_at"] ?: "now"))); ?>. You can now accept tasks in the Task Centre.</p>
        <a class="btn btn-orange" href="tasks.php">Open Task Centre <i class="fa-solid fa-arrow-right"></i></a>
      </div>
    <?php elseif ($status === "Pending"): ?>
      <div class="form-card">
        <h2><i class="fa-regular fa-hourglass-half" aria-hidden="true" style="color:var(--gold-deep)"></i> Verification under review</h2>
        <p class="lead-sm">Submitted on <?php echo h(date("d M Y, H:i", strtotime($vol["verification_submitted_at"] ?: "now"))); ?>. A coordinator is reviewing your ID and references. You will get a notification when a decision is made.</p>
        <p class="muted-small">Nothing more is needed from you right now.</p>
      </div>
    <?php else: ?>
      <?php if ($status === "Rejected"): ?>
        <div class="alert-box bad"><strong>Your last submission could not be approved.</strong><?php if (!empty($vol["verification_note"])): ?> Reason: <?php echo h($vol["verification_note"]); ?><?php endif; ?> You are welcome to submit again below.</div>
      <?php endif; ?>
      <div class="alert-box info"><i class="fa-solid fa-lock" aria-hidden="true"></i> <strong>How we handle your ID:</strong> the file is stored privately, can only be opened by Helping Hands administrators, and is <strong>deleted as soon as a decision is made</strong>. We only keep the outcome (verified or not).</div>
      <form class="form-card" method="post" enctype="multipart/form-data" novalidate>
        <input type="hidden" name="csrf" value="<?php echo h(csrf_token()); ?>">
        <?php if ($errors): ?><div class="form-errors"><ul><?php foreach ($errors as $e): ?><li><?php echo h($e); ?></li><?php endforeach; ?></ul></div><?php endif; ?>
        <h2>1. ID document</h2>
        <p class="lead-sm">A clear photo or scan of your ID card, passport or driver's licence (JPG, PNG or PDF, up to 3 MB). The name must match your account.</p>
        <div class="field"><label for="id_doc">ID document</label><input id="id_doc" name="id_doc" type="file" accept=".jpg,.jpeg,.png,.pdf,image/jpeg,image/png,application/pdf" required></div>

        <h2 style="margin-top:26px">2. Two references</h2>
        <p class="lead-sm">People who have known you for at least a year and are not family living with you, such as an employer, teacher, minister or neighbour. We may phone them.</p>
        <?php foreach ([1, 2] as $n): ?>
          <fieldset class="fieldset"><legend>Reference <?php echo $n; ?></legend>
            <div class="form-row">
              <div class="field"><label for="ref<?php echo $n; ?>_name">Full name</label><input id="ref<?php echo $n; ?>_name" name="ref<?php echo $n; ?>_name" required value="<?php echo h($old["ref{$n}_name"] ?: ($vol["ref{$n}_name"] ?? "")); ?>"></div>
              <div class="field"><label for="ref<?php echo $n; ?>_phone">Phone number</label><input id="ref<?php echo $n; ?>_phone" name="ref<?php echo $n; ?>_phone" type="tel" required value="<?php echo h($old["ref{$n}_phone"] ?: ($vol["ref{$n}_phone"] ?? "")); ?>"></div>
            </div>
            <div class="field"><label for="ref<?php echo $n; ?>_relationship">How do they know you?</label><input id="ref<?php echo $n; ?>_relationship" name="ref<?php echo $n; ?>_relationship" required placeholder="e.g. Former employer, 4 years" value="<?php echo h($old["ref{$n}_relationship"] ?: ($vol["ref{$n}_relationship"] ?? "")); ?>"></div>
          </fieldset>
        <?php endforeach; ?>

        <div class="check-row"><input id="consent" name="consent" type="checkbox" required><label for="consent">I confirm that everything above is true, that the ID is mine, and that Helping Hands may contact my references.</label></div>
        <div class="row-actions"><a class="btn btn-ghost" href="account.php">Cancel</a><button class="btn btn-orange" type="submit">Submit for verification <i class="fa-solid fa-paper-plane"></i></button></div>
      </form>
    <?php endif; ?>
  </div>
</section>
<?php page_end(); ?>
