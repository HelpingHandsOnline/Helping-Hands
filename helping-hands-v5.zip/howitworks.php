<?php require __DIR__ . "/config.php"; $activePage = "howitworks"; ?>
<!doctype html>
<html lang="<?php echo h(current_lang()); ?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Helping Hands | How It Works</title>
<meta name="description" content="See how Community Assist connects neighbours who need help with volunteers who want to give their time.">
<meta property="og:type" content="website">
<meta property="og:title" content="Helping Hands | How It Works">
<meta property="og:description" content="See how Community Assist connects neighbours who need help with volunteers who want to give their time.">
<meta property="og:image" content="logo.png">
<meta property="og:site_name" content="Helping Hands Community Assist">
<meta name="twitter:card" content="summary">
<meta name="twitter:title" content="Helping Hands | How It Works">
<meta name="twitter:description" content="See how Community Assist connects neighbours who need help with volunteers who want to give their time.">
<link rel="icon" href="logo.png"><link rel="manifest" href="manifest.webmanifest"><meta name="theme-color" content="#0b3329">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,600;0,700;1,600&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<link rel="stylesheet" href="common.css?v=5"><link rel="stylesheet" href="v5.css?v=5">
<link rel="stylesheet" href="howitworks.css?v=5">
<link rel="stylesheet" href="polish.css?v=1">
</head>
<body>
<a class="skip-link" href="#main">Skip to content</a>

<?php include __DIR__ . "/partials/header.php"; ?>

<main id="main">

<section class="section" style="padding-bottom:0">
  <div class="container section-title">
    <span class="eyebrow">SIMPLE. RESPECTFUL. LOCAL.</span>
    <h2 style="font-size:44px">How It Works</h2>
    <p style="max-width:560px;margin:0 auto">We make it simple to get help and build stronger communities by connecting neighbours and volunteers.</p>
  </div>
</section>

<?php $guide = ["who"=>"First-time visitors, people who need help, and people thinking about volunteering and wanting to understand each step.","what"=>"Follow a request from the first form to a completed task, and see when contact details are shared.","next"=>[["Request help","request.php"],["Volunteer","volunteer.php"],["Read the FAQs","resources.php#faq"]]]; include __DIR__ . "/partials/page-guide.php"; ?>

<section class="section" aria-labelledby="hiw-detail">
  <div class="container prose reveal">
    <span class="eyebrow">In plain words</span>
    <h2 id="hiw-detail">Everything you need to know before you begin</h2>
    <p>Helping Hands works like a community notice board with a few smart rules. People who need help post a request. People who want to help look at the open requests and choose one they can do. When a volunteer accepts a request, the two people are put in touch so they can sort out the details.</p>
    <h3>For people asking for help</h3>
    <p>You will need a free account. Once you are signed in, the request form asks what kind of help you need, where it is, when you need it, and how you would like to be contacted. The more detail you give, the easier it is for a volunteer to say yes. After you submit, your request is marked <strong>Pending</strong>. You do not need to do anything else until a volunteer accepts it.</p>
    <h3>For people offering help</h3>
    <p>Volunteers complete a short application once. It asks about the areas you can help in, when you are usually available, any skills or transport you can offer, and an emergency contact. After that you can browse open requests in the Task Centre, accept the ones that suit you, and mark them complete when you are done.</p>
    <h3>What happens to your information</h3>
    <p>Your contact details are shared only after a volunteer accepts your request. We ask only for what is needed to make the help happen, and explain how information is handled in our <a href="privacy.php" style="color:var(--gold-deep);font-weight:700">Privacy Policy</a>.</p>
    <h3>If something changes</h3>
    <p>Plans change. If you can no longer do a task you accepted, or no longer need the help you asked for, please get in touch through the <a href="contact.php" style="color:var(--gold-deep);font-weight:700">Contact page</a> as soon as you can so that nobody is left waiting.</p>
  </div>
</section>

<section class="section">
  <div class="container">
    <div class="icon-steps">
      <div class="icon-step">
        <span class="step-badge">1</span>
        <div class="step-icon"><i class="fa-solid fa-pen-to-square"></i></div>
        <h3>Submit a Request</h3>
        <p>Tell us what help you need.</p>
      </div>
      <div class="icon-arrow"><i class="fa-solid fa-arrow-right"></i></div>
      <div class="icon-step">
        <span class="step-badge">2</span>
        <div class="step-icon"><i class="fa-solid fa-people-group"></i></div>
        <h3>Volunteer Accepts</h3>
        <p>A local volunteer chooses to help.</p>
      </div>
      <div class="icon-arrow"><i class="fa-solid fa-arrow-right"></i></div>
      <div class="icon-step">
        <span class="step-badge">3</span>
        <div class="step-icon"><i class="fa-solid fa-location-dot"></i></div>
        <h3>Get Connected</h3>
        <p>Contact details and address are shared after acceptance.</p>
      </div>
      <div class="icon-arrow"><i class="fa-solid fa-arrow-right"></i></div>
      <div class="icon-step">
        <span class="step-badge">4</span>
        <div class="step-icon"><i class="fa-solid fa-circle-check"></i></div>
        <h3>Task Completed</h3>
        <p>The volunteer marks the task complete and it is recorded on your account.</p>
      </div>
    </div>
  </div>
</section>

<section class="section" style="padding-top:0">
  <div class="container">
    <div class="section-title reveal">
      <span class="eyebrow">OUR PRINCIPLES</span>
      <h2>Why it matters</h2>
      <p>Every request and every task follows the same guiding principles.</p>
    </div>
    <div class="value-grid">
      <div class="value-card">
        <i class="fa-solid fa-people-roof"></i>
        <h3>Stronger Communities</h3>
        <p>Helping each other creates stronger, safer neighbourhoods.</p>
      </div>
      <div class="value-card">
        <i class="fa-solid fa-shield-heart"></i>
        <h3>Safe &amp; Trusted</h3>
        <p>Volunteers apply with an emergency contact, and your details are shared only after a request is accepted.</p>
      </div>
      <div class="value-card">
        <i class="fa-solid fa-people-group"></i>
        <h3>More Connections</h3>
        <p>Build relationships and bring people together.</p>
      </div>
      <div class="value-card">
        <i class="fa-solid fa-scale-balanced"></i>
        <h3>Fair for Everyone</h3>
        <p>Clear rules keep the platform fair, whether you're asking or giving help.</p>
      </div>
    </div>
  </div>
</section>

<section class="section" style="padding-top:0">
  <div class="container">
    <div class="section-title reveal">
      <span class="eyebrow">GOOD TO KNOW</span>
      <h2>The rules that keep this fair</h2>
      <p>A short summary of the guidelines behind every request and task.</p>
    </div>
    <div class="grid4">
      <div class="category">
        <div class="category-icon"><i class="fa-solid fa-user-check"></i></div>
        <h3>One Active Request</h3>
        <p>Neighbours may have one active request at a time, so nobody is left waiting behind a queue.</p>
      </div>
      <div class="category">
        <div class="category-icon"><i class="fa-solid fa-clock"></i></div>
        <h3>72-Hour Window</h3>
        <p>A request expires after 72 hours if no volunteer accepts it, and can simply be reposted.</p>
      </div>
      <div class="category">
        <div class="category-icon"><i class="fa-solid fa-hand-holding-heart"></i></div>
        <h3>One Task at a Time</h3>
        <p>Volunteers accept one active task at a time, so every request gets proper attention.</p>
      </div>
      <div class="category">
        <div class="category-icon"><i class="fa-solid fa-lock"></i></div>
        <h3>Privacy Protected</h3>
        <p>Contact details and addresses are only shared once a volunteer formally accepts.</p>
      </div>
    </div>
  </div>
</section>

<div class="cta">
  <div class="cta-icon"><i class="fa-regular fa-heart"></i></div>
  <div class="cta-copy"><strong>Ready to make a difference?</strong><span>Join our community of volunteers and start helping neighbours today.</span></div>
  <a class="btn btn-orange" href="volunteer.php">Become a Volunteer <i class="fa-solid fa-arrow-right"></i></a>
</div>


<section class="section tint" aria-labelledby="expect-title">
  <div class="container">
    <div class="section-title reveal"><span class="eyebrow">Before you start</span><h2 id="expect-title">What to expect</h2><p>A few things worth knowing, whether you are asking for help or giving it.</p></div>
    <div class="who-grid">
      <article class="panel who-card reveal"><h3>If you are asking for help</h3>
        <ul class="feature-list"><li>Create an account, then fill in the request form with what you need, where, and when.</li><li>Include useful detail, such as the shop, pharmacy or appointment address.</li><li>Your request shows as <strong>Pending</strong> until a volunteer accepts it.</li><li>You can follow its status in your Task Centre.</li></ul></article>
      <article class="panel who-card reveal reveal-1"><h3>If you are volunteering</h3>
        <ul class="feature-list"><li>Complete the volunteer application once, including an emergency contact.</li><li>Open the Task Centre to see requests waiting for a volunteer.</li><li>Accept only what you can realistically do, and on time.</li><li>Mark the task complete when you have finished.</li></ul></article>
    </div>
    <p class="notice"><i class="fa-solid fa-triangle-exclamation" aria-hidden="true"></i> Helping Hands is not an emergency service. In an emergency, contact your local emergency services immediately.</p>
  </div>
</section>
</main>



<?php include __DIR__ . "/partials/footer.php"; ?>
</body>
</html>
