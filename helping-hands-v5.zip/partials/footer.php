<?php require_once __DIR__ . "/social.php"; ?>
<footer class="footer">
  <div class="footer-cta">
    <div class="container footer-cta-inner">
      <div><h2><?php echo h(t("f.cta.h")); ?></h2><p><?php echo h(t("f.cta.p")); ?></p></div>
      <div class="footer-cta-btns">
        <a class="btn btn-orange" href="<?php echo logged_in() ? "request.php" : "signup.php"; ?>"><?php echo h(logged_in() ? t("f.request") : t("f.start")); ?> <i class="fa-solid fa-arrow-right" aria-hidden="true"></i></a>
        <a class="btn btn-outline" href="volunteer.php"><?php echo h(t("f.become")); ?></a>
      </div>
    </div>
  </div>
  <div class="container footer-grid">
    <div class="footer-brand">
      <a class="logo" href="index.php" aria-label="Helping Hands Community Assist — home">
        <img src="logo.png" alt="" width="44" height="44" loading="lazy">
        <span class="logo-text"><strong>Helping Hands</strong><span>COMMUNITY ASSIST</span></span>
      </a>
      <p><?php echo h(t("f.blurb")); ?></p>
      <h4 class="follow"><?php echo h(t("f.follow")); ?></h4>
      <?php render_social("on-dark"); ?>
    </div>
    <nav class="footer-col" aria-label="Explore">
      <h4><?php echo h(t("f.explore")); ?></h4>
      <a href="index.php"><?php echo h(t("nav.home")); ?></a>
      <a href="howitworks.php"><?php echo h(t("nav.how")); ?></a>
      <a href="about.php"><?php echo h(t("f.about")); ?></a>
      <a href="resources.php"><?php echo h(t("nav.resources")); ?></a>
      <a href="resources.php#faq"><?php echo h(t("top.faqs")); ?></a>
      <a href="contact.php"><?php echo h(t("nav.contact")); ?></a>
    </nav>
    <nav class="footer-col" aria-label="Get involved">
      <h4><?php echo h(t("f.involved")); ?></h4>
      <?php if (logged_in()): ?>
        <a href="account.php"><?php echo h(t("btn.account")); ?></a>
        <a href="tasks.php"><?php echo h(t("nav.tasks")); ?></a>
        <a href="notifications.php"><?php echo h(t("notifications")); ?></a>
        <a href="request.php"><?php echo h(t("nav.request")); ?></a>
        <a href="volunteer.php"><?php echo h(t("f.volapp")); ?></a>
        <a href="logout.php"><?php echo h(t("btn.logout")); ?></a>
      <?php else: ?>
        <a href="request.php"><?php echo h(t("nav.request")); ?></a>
        <a href="volunteer.php"><?php echo h(t("f.becomevol")); ?></a>
        <a href="signup.php"><?php echo h(t("f.create")); ?></a>
        <a href="login.php"><?php echo h(t("btn.login")); ?></a>
      <?php endif; ?>
    </nav>
    <div class="footer-col">
      <h4><?php echo h(t("f.safety")); ?></h4>
      <a href="privacy.php"><?php echo h(t("f.privacy")); ?></a>
      <a href="terms.php"><?php echo h(t("f.terms")); ?></a>
      <a href="resources.php"><?php echo h(t("f.tips")); ?></a>
      <p class="footer-note"><i class="fa-solid fa-triangle-exclamation" aria-hidden="true"></i> <?php echo h(t("f.note")); ?></p>
    </div>
  </div>
  <div class="container footer-bottom">
    <span>&copy; <?php echo date("Y"); ?> Helping Hands Community Assist. All rights reserved.</span>
    <span><a href="privacy.php">Privacy</a> &nbsp;·&nbsp; <a href="terms.php">Terms</a> &nbsp;·&nbsp; <a href="#top" id="footTop"><?php echo h(t("f.top")); ?></a></span>
  </div>
</footer>
<button class="to-top" id="toTop" type="button" aria-label="Back to top"><i class="fa-solid fa-arrow-up" aria-hidden="true"></i></button>
<script src="common.js?v=8" defer></script>
