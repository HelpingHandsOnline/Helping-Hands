<?php
/** Expects $guide = ["who"=>..., "what"=>..., "next"=>[[label,url],...]] */
if (empty($guide)) return;
?>
<section class="page-guide" aria-label="About this page">
  <div class="container guide-grid">
    <div class="guide-item"><i class="fa-solid fa-user-group" aria-hidden="true"></i><div><h2>Who this page is for</h2><p><?php echo h($guide["who"]); ?></p></div></div>
    <div class="guide-item"><i class="fa-solid fa-circle-info" aria-hidden="true"></i><div><h2>What you can do here</h2><p><?php echo h($guide["what"]); ?></p></div></div>
    <div class="guide-item"><i class="fa-solid fa-route" aria-hidden="true"></i><div><h2>Where to go next</h2><p class="guide-links"><?php foreach ($guide["next"] as $i => $n): ?><a href="<?php echo h($n[1]); ?>"><?php echo h($n[0]); ?></a><?php endforeach; ?></p></div></div>
  </div>
</section>
