<?php
/**
 * partials/header.php — shared header for every page.
 * Included after config.php, so login state is accurate everywhere.
 * Expects $activePage (e.g. "login") to highlight the matching nav link.
 */
$activePage = $activePage ?? "";
$__me = logged_in() ? user() : null;
$__unread = $__me ? unread_count() : 0;
$__isAdmin = $__me && !empty($__me["is_admin"]);
$__initial = $__me ? strtoupper(mb_substr($__me["first_name"], 0, 1) . mb_substr($__me["last_name"], 0, 1)) : "";

if (!function_exists("navActive")) {
    function navActive($page, $active) {
        return $page === $active ? ' class="active" aria-current="page"' : "";
    }
}
?>
<script>document.documentElement.classList.add("js");</script>
<?php require_once __DIR__ . "/social.php"; ?>
<div class="topbar">
  <div class="container topbar-inner">
    <span class="topbar-msg"><i class="fa-solid fa-heart" aria-hidden="true"></i> <?php echo h(t("top.msg")); ?></span>
    <span class="topbar-note"><i class="fa-solid fa-triangle-exclamation" aria-hidden="true"></i> <?php echo h(t("top.note")); ?></span>
    <span class="topbar-right"><div class="lang-switch" aria-label="<?php echo h(t("language")); ?>"><i class="fa-solid fa-globe" aria-hidden="true"></i>
      <?php foreach (langs() as $__code => $__name): ?><a href="<?php echo h(lang_url($__code)); ?>" hreflang="<?php echo h($__code); ?>" lang="<?php echo h($__code); ?>"<?php echo $__code === current_lang() ? ' class="on" aria-current="true"' : ''; ?>><?php echo h(strtoupper($__code)); ?></a><?php endforeach; ?>
    </div><a href="resources.php#faq"><?php echo h(t("top.faqs")); ?></a><a href="contact.php"><?php echo h(t("nav.contact")); ?></a><?php render_social("on-dark small"); ?></span>
  </div>
</div>
<header class="site-header" id="siteHeader">
  <a class="logo" href="index.php" aria-label="Helping Hands Community Assist — home">
    <img src="logo.png" alt="" width="46" height="46">
    <span class="logo-text"><strong>Helping Hands</strong><span>COMMUNITY ASSIST</span></span>
  </a>
  <?php if ($__me): ?><a class="bell bell-mobile" href="notifications.php" aria-label="<?php echo h(t("notifications")); ?><?php echo $__unread ? " (" . $__unread . ")" : ""; ?>"><i class="fa-regular fa-bell" aria-hidden="true"></i><?php if ($__unread): ?><span class="bell-count"><?php echo $__unread > 99 ? "99+" : $__unread; ?></span><?php endif; ?></a><?php endif; ?>
  <button class="menu" id="menuBtn" type="button" aria-label="Open menu" aria-expanded="false" aria-controls="nav"><i class="fa-solid fa-bars" aria-hidden="true"></i></button>
  <nav class="nav" id="nav" aria-label="Main navigation">
    <a href="index.php"<?php echo navActive("home", $activePage); ?>><?php echo h(t("nav.home")); ?></a>
    <a href="howitworks.php"<?php echo navActive("howitworks", $activePage); ?>><?php echo h(t("nav.how")); ?></a>
    <a href="request.php"<?php echo navActive("request", $activePage); ?>><?php echo h(t("nav.request")); ?></a>
    <a href="volunteer.php"<?php echo navActive("volunteer", $activePage); ?>><?php echo h(t("nav.volunteer")); ?></a>
    <?php if ($__isAdmin): ?><a href="admin.php"<?php echo navActive("admin", $activePage); ?>><?php echo h(t("admin")); ?></a><?php endif; ?>
    <?php if ($__me): ?><a href="tasks.php"<?php echo navActive("tasks", $activePage); ?>><?php echo h(t("nav.tasks")); ?></a><?php endif; ?>
    <a href="about.php"<?php echo navActive("about", $activePage); ?>><?php echo h(t("nav.about")); ?></a>
    <a href="resources.php"<?php echo navActive("resources", $activePage); ?>><?php echo h(t("nav.resources")); ?></a>
    <a href="contact.php"<?php echo navActive("contact", $activePage); ?>><?php echo h(t("nav.contact")); ?></a>
    <div class="nav-cta-mobile">
      <button type="button" class="btn btn-outline install-btn" hidden><i class="fa-solid fa-download" aria-hidden="true"></i> Install app</button>
      <?php if ($__me): ?>
        <a class="btn btn-outline" href="account.php"><?php echo h(t("btn.account")); ?></a>
        <a class="btn btn-orange" href="logout.php"><?php echo h(t("btn.logout")); ?></a>
      <?php else: ?>
        <a class="btn btn-outline" href="login.php"><?php echo h(t("btn.login")); ?></a>
        <a class="btn btn-orange" href="signup.php"><?php echo h(t("btn.signup")); ?></a>
      <?php endif; ?>
    </div>
  </nav>
  <div class="actions">
    <button type="button" class="btn btn-outline small install-btn" hidden><i class="fa-solid fa-download" aria-hidden="true"></i> Install app</button>
    <?php if ($__me): ?>
      <a class="bell" href="notifications.php" aria-label="<?php echo h(t("notifications")); ?><?php echo $__unread ? " (" . $__unread . ")" : ""; ?>"><i class="fa-regular fa-bell" aria-hidden="true"></i><?php if ($__unread): ?><span class="bell-count"><?php echo $__unread > 99 ? "99+" : $__unread; ?></span><?php endif; ?></a>
      <div class="user-chip">
        <div class="avatar" aria-hidden="true"><?php echo h($__initial ?: "HH"); ?></div>
        <span class="hello"><?php echo h(t("hi")); ?>, <?php echo h($__me["first_name"]); ?><small><?php echo h(t("signedin")); ?></small></span>
      </div>
      <a class="btn btn-outline small" href="account.php"><?php echo h(t("btn.account")); ?></a>
      <a class="btn btn-orange small" href="logout.php"><?php echo h(t("btn.logout")); ?></a>
    <?php else: ?>
      <a class="btn btn-outline small<?php echo $activePage === "login" ? " active" : ""; ?>" href="login.php"><?php echo h(t("btn.login")); ?></a>
      <a class="btn btn-orange small<?php echo $activePage === "signup" ? " active" : ""; ?>" href="signup.php"><?php echo h(t("btn.signup")); ?></a>
    <?php endif; ?>
  </div>
</header>
<?php $__flash = get_flash(); if ($__flash): ?>
  <div class="flash-banner flash-<?php echo h($__flash["type"]); ?>" role="status" aria-live="polite">
    <div class="container">
      <i class="fa-solid <?php echo $__flash["type"] === "success" ? "fa-circle-check" : "fa-triangle-exclamation"; ?>" aria-hidden="true"></i>
      <span><?php echo h($__flash["message"]); ?></span>
    </div>
  </div>
<?php endif; ?>
