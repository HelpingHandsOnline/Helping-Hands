<?php
/**
 * Renders social icons. Real links come from social-links.php.
 * Icons only appear when they have a real address, so there are no dead buttons.
 */
if (!function_exists("render_social")) {
    function render_social(string $class = ""): void {
        $links = is_file(__DIR__ . "/../social-links.php") ? (include __DIR__ . "/../social-links.php") : [];
        if (!is_array($links)) $links = [];
        $icons = [
            "facebook"  => ["fa-brands fa-facebook-f", "Facebook"],
            "instagram" => ["fa-brands fa-instagram", "Instagram"],
            "x"         => ["fa-brands fa-x-twitter", "X (Twitter)"],
            "youtube"   => ["fa-brands fa-youtube", "YouTube"],
            "whatsapp"  => ["fa-brands fa-whatsapp", "WhatsApp"],
            "linkedin"  => ["fa-brands fa-linkedin-in", "LinkedIn"],
            "tiktok"    => ["fa-brands fa-tiktok", "TikTok"],
        ];
        // WhatsApp can be built from the verified phone number in site-settings.php
        if (empty($links["whatsapp"]) && function_exists("setting") && setting("verified")) {
            $wa = preg_replace("/\\D/", "", to_e164((string)setting("whatsapp")));
            if (strlen($wa) >= 9) $links["whatsapp"] = "https://wa.me/" . $wa;
        }
        $rows = "";
        foreach ($icons as $key => $meta) {
            $url = isset($links[$key]) && is_string($links[$key]) && preg_match('~^https?://~i', $links[$key]) ? $links[$key] : "";
            if ($url === "") continue;   // no real address yet: show nothing rather than a dead button
            $rows .= '<a class="social-link" href="' . h($url) . '" target="_blank" rel="noopener noreferrer" aria-label="' . h($meta[1]) . ' (opens in a new tab)"><i class="' . h($meta[0]) . '" aria-hidden="true"></i></a>';
        }
        if ($rows === "") return;
        echo '<div class="social-row ' . h($class) . '" role="group" aria-label="Social media">' . $rows . '</div>';
    }
}
