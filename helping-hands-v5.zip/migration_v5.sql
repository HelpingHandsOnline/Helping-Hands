-- Helping Hands v5 — NON-DESTRUCTIVE upgrade for a database that already has data.
-- Import this in phpMyAdmin (Import tab) on top of your existing v4 database.
-- It only ADDS columns and tables. Nothing is dropped or deleted. Safe to run twice.

ALTER TABLE users
  ADD COLUMN IF NOT EXISTS is_admin TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS notify_email TINYINT(1) NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS notify_sms TINYINT(1) NOT NULL DEFAULT 0;

ALTER TABLE requests
  ADD COLUMN IF NOT EXISTS updated_at DATETIME NULL,
  ADD COLUMN IF NOT EXISTS cancelled_at DATETIME NULL,
  ADD COLUMN IF NOT EXISTS cancel_reason VARCHAR(255) NULL;

ALTER TABLE volunteers
  ADD COLUMN IF NOT EXISTS verification_status ENUM('Unverified','Pending','Verified','Rejected') NOT NULL DEFAULT 'Unverified',
  ADD COLUMN IF NOT EXISTS id_document VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS ref1_name VARCHAR(120) NULL,
  ADD COLUMN IF NOT EXISTS ref1_phone VARCHAR(40) NULL,
  ADD COLUMN IF NOT EXISTS ref1_relationship VARCHAR(80) NULL,
  ADD COLUMN IF NOT EXISTS ref2_name VARCHAR(120) NULL,
  ADD COLUMN IF NOT EXISTS ref2_phone VARCHAR(40) NULL,
  ADD COLUMN IF NOT EXISTS ref2_relationship VARCHAR(80) NULL,
  ADD COLUMN IF NOT EXISTS verification_submitted_at DATETIME NULL,
  ADD COLUMN IF NOT EXISTS verification_note VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS verified_at DATETIME NULL,
  ADD COLUMN IF NOT EXISTS verified_by INT UNSIGNED NULL;

CREATE TABLE IF NOT EXISTS password_resets (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  token_hash CHAR(64) NOT NULL,
  expires_at DATETIME NOT NULL,
  used_at DATETIME NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_reset_token (token_hash),
  INDEX idx_reset_user (user_id),
  CONSTRAINT fk_reset_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS notifications (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  type VARCHAR(40) NOT NULL,
  title VARCHAR(160) NOT NULL,
  body TEXT NULL,
  link VARCHAR(190) NULL,
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_notif_user (user_id, is_read),
  CONSTRAINT fk_notif_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS ratings (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  request_id INT UNSIGNED NOT NULL UNIQUE,
  rater_id INT UNSIGNED NOT NULL,
  volunteer_id INT UNSIGNED NOT NULL,
  stars TINYINT UNSIGNED NOT NULL,
  comment VARCHAR(500) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_rating_volunteer (volunteer_id),
  CONSTRAINT fk_rating_request FOREIGN KEY (request_id) REFERENCES requests(id) ON DELETE CASCADE,
  CONSTRAINT fk_rating_rater FOREIGN KEY (rater_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_rating_volunteer FOREIGN KEY (volunteer_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS email_log (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NULL,
  channel ENUM('email','sms') NOT NULL DEFAULT 'email',
  to_address VARCHAR(190) NOT NULL,
  subject VARCHAR(250) NOT NULL,
  body TEXT NULL,
  status ENUM('sent','failed') NOT NULL,
  error_text VARCHAR(500) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_log_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------
-- MAKE YOURSELF AN ADMINISTRATOR (edit the e-mail, then run just this line):
-- UPDATE users SET is_admin = 1 WHERE email = 'your-account-email@example.com';
-- ---------------------------------------------------------------
