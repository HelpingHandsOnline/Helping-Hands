<?php
require 'config.php'; require_login();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect('tasks.php');
verify_csrf();
$id = post_id('request_id');
$me = user();

$q = $pdo->prepare("UPDATE requests SET status='Completed', completed_at=NOW() WHERE id=? AND volunteer_id=? AND status='Accepted'");
$q->execute([$id, $me['id']]);

if ($q->rowCount()) {
    $r = $pdo->prepare('SELECT user_id, category FROM requests WHERE id=?');
    $r->execute([$id]);
    $req = $r->fetch();
    if ($req) {
        notify((int)$req['user_id'], 'completed', 'Your request was completed',
            $me['first_name'] . ' marked your ' . $req['category'] . ' request as completed. Please take a moment to rate how it went. It helps keep the community safe.',
            'rate.php?request_id=' . $id);
    }
    flash('success', 'Task marked as completed. Thank you for helping!');
} else {
    flash('error', 'This task could not be updated.');
}
redirect('tasks.php');
