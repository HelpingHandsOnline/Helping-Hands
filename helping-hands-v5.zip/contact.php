<?php
require __DIR__ . "/config.php";
$activePage = "contact";
$old = ["name" => "", "email" => "", "subject" => "", "messageText" => ""];
$errors = [];

if (logged_in()) {
    $me = user();
    $old["name"] = $me["first_name"] . " " . $me["last_name"];
    $old["email"] = $me["email"];
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    verify_csrf();
    $old["name"]        = trim($_POST["name"] ?? "");
    $old["email"]       = trim($_POST["email"] ?? "");
    $old["subject"]     = trim($_POST["subject"] ?? "");
    $old["messageText"] = trim($_POST["messageText"] ?? "");
    $consent            = isset($_POST["consent"]);

    if ($old["name"] === "") $errors[] = "Please enter your name.";
    if ($old["email"] === "" || !filter_var($old["email"], FILTER_VALIDATE_EMAIL)) $errors[] = "Please enter a valid email address.";
    if ($old["subject"] === "") $errors[] = "Please choose a subject.";
    if (strlen($old["messageText"]) < 10) $errors[] = "Please write at least 10 characters.";
    if (!$consent) $errors[] = "Please confirm before sending.";

    if (!$errors) {
        $stmt = $pdo->prepare("INSERT INTO contact_messages (user_id, name, email, subject, message) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([logged_in() ? user()["id"] : null, $old["name"], $old["email"], $old["subject"], $old["messageText"]]);
        flash("success", "Thanks — your message has been saved. We'll be in touch within 24 hours.");
        redirect("contact.php");
    }
}
?>
<!doctype html>
<html lang="<?php echo h(current_lang()); ?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Helping Hands | Contact Us</title>
<meta name="description" content="Reach out to the Helping Hands Community Assist team with any questions, feedback, or suggestions. We're here to help.">
<meta property="og:type" content="website">
<meta property="og:title" content="Helping Hands | Contact Us">
<meta property="og:description" content="Reach out to the Helping Hands Community Assist team with any questions, feedback, or suggestions. We're here to help.">
<meta property="og:image" content="logo.png">
<meta property="og:site_name" content="Helping Hands Community Assist">
<meta name="twitter:card" content="summary">
<meta name="twitter:title" content="Helping Hands | Contact Us">
<meta name="twitter:description" content="Reach out to the Helping Hands Community Assist team with any questions, feedback, or suggestions. We're here to help.">
<link rel="icon" href="logo.png"><link rel="manifest" href="manifest.webmanifest"><meta name="theme-color" content="#0b3329">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,600;0,700;1,600&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<link rel="stylesheet" href="common.css?v=5"><link rel="stylesheet" href="v5.css?v=5">
<link rel="stylesheet" href="contact.css?v=5">
<link rel="stylesheet" href="polish.css?v=1">
</head>
<body>
<a class="skip-link" href="#main">Skip to content</a>

<?php include __DIR__ . "/partials/header.php"; ?>

<main id="main">

<section class="page-hero contact-hero">
  <div class="container hero-grid">
    <div class="hero-copy">
      <span class="eyebrow">GET IN TOUCH</span>
      <h1>Contact <span>Us.</span></h1>
      <p>We'd love to hear from you! Reach out with any questions, feedback, or suggestions — we're here to help.</p>
      <div class="hero-note">
        <span><i class="fa-solid fa-clock"></i> We reply within 24 hours</span>
        <span><i class="fa-solid fa-lock"></i> Your details stay private</span>
      </div>
    </div>
    <div class="hero-image-wrap with-orbit">
      <img class="hero-image" src="<?php echo h(photo('contact-1', 'https://images.unsplash.com/photo-1423666639041-f56000c27a9a?auto=format&fit=crop&w=1100&q=88')); ?>" alt="A phone, envelope and location pin icons on a desk representing ways to get in touch" onerror="this.onerror=null;this.src='images/illus-community.svg'">
    </div>
  </div>
</section>

<?php $guide = ["who"=>"Anyone with a question, a suggestion or a concern about Helping Hands, whether you are a requester, a volunteer or a visitor.","what"=>"Send us a message, find our contact details and read quick answers to common questions.","next"=>[["Resources & FAQs","resources.php#faq"],["How it works","howitworks.php"],["Safety information","resources.php"]]]; include __DIR__ . "/partials/page-guide.php"; ?>

<section class="section" aria-labelledby="con-detail">
  <div class="container prose reveal">
    <span class="eyebrow">Before you write</span>
    <h2 id="con-detail">How we can help you</h2>
    <p>The Contact page is the best place to reach us with a question about using Helping Hands, a suggestion for improving it, feedback about your experience, or a concern about safety.</p>
    <h3>What to include</h3>
    <p>Please tell us what your message is about, and give an email address or phone number where we can reply. If your message is about a particular request, mention what the request was for and roughly when it was made.</p>
    <h3>Locked out of your account?</h3>
    <p>Use <a href="forgot-password.php" style="text-decoration:underline;font-weight:700">Forgot Password</a> on the log-in page and we will e-mail you a secure reset link. If it does not arrive within a few minutes, check your spam folder or send us a message from the e-mail address on your account and we will help you get back in.</p>
    <h3>Urgent situations</h3>
    <p>Helping Hands is not an emergency service. If someone is in danger or needs urgent medical help, contact your local emergency services immediately.</p>
  </div>
</section>

<section class="section" style="padding-top:0">
  <div class="container">
    <div class="urgent-banner">
      <i class="fa-solid fa-headset"></i>
      <div>
        <strong>Need immediate help?</strong>
        <span>For urgent assistance, please call our helpline directly rather than using the form below.</span>
      </div>
      <a class="btn btn-orange" href="tel:+27123456790">Call Now <i class="fa-solid fa-phone"></i></a>
    </div>

    <div class="contact-grid">
      <div class="info-card">
        <h2>Get in Touch</h2>

        <?php if (!setting('verified')): ?><div class="alert-box warn" style="margin-bottom:16px"><i class="fa-solid fa-circle-info" aria-hidden="true"></i> Our public contact details are being confirmed. Please use the contact form below and we will reply to you directly.</div><?php endif; ?>
        <div class="info-item">
          <div class="info-icon"><i class="fa-solid fa-phone"></i></div>
          <div>
            <small>Phone</small>
            <strong><?php echo h(setting('phone')); ?></strong>
            <span><?php echo h(setting('hours')); ?></span>
          </div>
        </div>

        <div class="info-item">
          <div class="info-icon"><i class="fa-regular fa-envelope"></i></div>
          <div>
            <small>Email</small>
            <strong><?php echo h(setting('email')); ?></strong>
            <span>We reply within 24 hours</span>
          </div>
        </div>

        <div class="info-item">
          <div class="info-icon"><i class="fa-solid fa-location-dot"></i></div>
          <div>
            <small>Address</small>
            <strong><?php echo h(setting('address_line1')); ?></strong>
            <span><?php echo h(setting('address_line2')); ?></span>
          </div>
        </div>

        <div class="info-item">
          <div class="info-icon"><i class="fa-regular fa-clock"></i></div>
          <div>
            <small>Office Hours</small>
            <strong><?php echo h(setting('hours')); ?></strong>
            <span>Closed on public holidays</span>
          </div>
        </div>

        <div class="info-item">
          <div class="info-icon"><i class="fa-brands fa-whatsapp"></i></div>
          <div>
            <small>WhatsApp</small>
            <strong><?php echo h(setting('whatsapp')); ?></strong>
            <span>Quick questions, 7 days a week</span>
          </div>
        </div>

        <div class="socials">
          <a href="https://www.facebook.com/" target="_blank" rel="noopener" aria-label="Facebook (opens in a new tab)"><i class="fa-brands fa-facebook-f"></i></a>
          <a href="https://www.instagram.com/" target="_blank" rel="noopener" aria-label="Instagram (opens in a new tab)"><i class="fa-brands fa-instagram"></i></a>
          <a href="https://twitter.com/" target="_blank" rel="noopener" aria-label="Twitter (opens in a new tab)"><i class="fa-brands fa-twitter"></i></a>
          <a href="https://www.youtube.com/" target="_blank" rel="noopener" aria-label="YouTube (opens in a new tab)"><i class="fa-brands fa-youtube"></i></a>
        </div>
      </div>

      <div class="form-card">
        <h2>Send Us a Message</h2>
        <p>Fill in the form below and a real person from our team will get back to you.</p>
        <form method="post" action="contact.php" novalidate>
          <input type="hidden" name="csrf" value="<?php echo h(csrf_token()); ?>">
          <?php if ($errors): ?>
            <div class="form-alert show"><?php echo implode("<br>", array_map("h", $errors)); ?></div>
          <?php endif; ?>
          <div class="form-row">
            <div class="field">
              <label for="name">Your Name <span>*</span></label>
              <input id="name" name="name" type="text" required autocomplete="name" value="<?php echo h($old["name"]); ?>" placeholder="Enter your name">
              <span class="field-error">Please enter your name.</span>
            </div>
            <div class="field">
              <label for="email">Email Address <span>*</span></label>
              <input id="email" name="email" type="email" required autocomplete="email" value="<?php echo h($old["email"]); ?>" placeholder="Enter your email">
              <span class="field-error">Please enter a valid email address.</span>
            </div>
          </div>
          <div class="field">
            <label for="subject">Subject <span>*</span></label>
            <select id="subject" name="subject" required>
              <option value="">Select a subject</option>
              <?php foreach (["General Enquiry", "Requesting Help", "Volunteering", "Account & Login Issue", "Feedback or Suggestion", "Report a Concern"] as $opt): ?>
                <option <?php echo $old["subject"] === $opt ? "selected" : ""; ?>><?php echo h($opt); ?></option>
              <?php endforeach; ?>
            </select>
            <span class="field-error">Please choose a subject.</span>
          </div>
          <div class="field">
            <label for="messageText">Message <span>*</span> <span class="hint">Minimum 10 characters</span></label>
            <textarea id="messageText" name="messageText" required minlength="10" placeholder="Type your message here..."><?php echo h($old["messageText"]); ?></textarea>
            <span class="field-error">Please write at least 10 characters.</span>
          </div>
          <div class="field" style="display:flex;align-items:flex-start;gap:9px">
            <input id="consent" name="consent" type="checkbox" required style="width:auto;margin-top:3px">
            <label for="consent" style="margin:0;font-weight:500">I agree that Helping Hands may contact me about this message.</label>
            <span class="field-error">Please confirm before sending.</span>
          </div>
          <button type="submit" class="btn btn-orange" style="width:100%;padding:13px">Send Message <i class="fa-solid fa-paper-plane"></i></button>
          <p class="form-note">Your message is saved securely and our team will read it. No email confirmation is sent automatically.</p>
        </form>
      </div>
    </div>
  </div>
</section>

<section class="section" style="padding-top:0">
  <div class="container">
    <div class="section-title reveal">
      <span class="eyebrow">WHO TO CONTACT</span>
      <h2>Reach the right team</h2>
      <p>Some enquiries are best sent directly to the team that handles them.</p>
    </div>
    <div class="dept-grid">
      <div class="dept-card">
        <i class="fa-solid fa-comments"></i>
        <h3>General Enquiries</h3>
        <p>Questions about the platform or how it works.</p>
        <a href="mailto:hello@helpinghands.org">hello@helpinghands.org</a>
      </div>
      <div class="dept-card">
        <i class="fa-solid fa-hands-holding-circle"></i>
        <h3>Volunteering</h3>
        <p>Questions about signing up or managing tasks.</p>
        <a href="mailto:<?php echo h(setting('email_volunteer')); ?>"><?php echo h(setting('email_volunteer')); ?></a>
      </div>
      <div class="dept-card">
        <i class="fa-solid fa-shield-halved"></i>
        <h3>Safeguarding &amp; Trust</h3>
        <p>Report a safety concern about a request or task.</p>
        <a href="mailto:<?php echo h(setting('email_trust')); ?>"><?php echo h(setting('email_trust')); ?></a>
      </div>
      <div class="dept-card">
        <i class="fa-solid fa-newspaper"></i>
        <h3>Media &amp; Partnerships</h3>
        <p>Press enquiries and community partnerships.</p>
        <a href="mailto:media@helpinghands.org">media@helpinghands.org</a>
      </div>
    </div>
  </div>
</section>

<section class="section" style="padding-top:0">
  <div class="container">
    <div class="section-title reveal">
      <span class="eyebrow">QUICK HELP</span>
      <h2>Find quick answers to common questions</h2>
    </div>
    <div class="grid4">
      <a class="category" href="request.php">
        <div class="category-icon"><i class="fa-regular fa-circle-question"></i></div>
        <h3>How to Request Help</h3>
        <p>Step-by-step guidance on submitting a request.</p>
        <span class="link">Learn more →</span>
      </a>
      <a class="category" href="volunteer.php">
        <div class="category-icon"><i class="fa-regular fa-heart"></i></div>
        <h3>How to Volunteer</h3>
        <p>Everything to get started as a volunteer.</p>
        <span class="link">Learn more →</span>
      </a>
      <a class="category" href="login.php">
        <div class="category-icon"><i class="fa-regular fa-user"></i></div>
        <h3>Account &amp; Login Help</h3>
        <p>Trouble signing in or creating an account.</p>
        <span class="link">Learn more →</span>
      </a>
      <a class="category" href="resources.php">
        <div class="category-icon"><i class="fa-regular fa-comment-dots"></i></div>
        <h3>General Questions</h3>
        <p>Browse our full resource library.</p>
        <span class="link">Learn more →</span>
      </a>
    </div>
  </div>
</section>

<section class="section map-section" style="padding-top:0">
  <div class="container map-grid">
    <div class="find-copy">
      <span class="eyebrow">VISIT US</span>
      <h2>Find us</h2>
      <p>Our community office is open to walk-ins during office hours — come say hello, ask a question, or drop off a donation.</p>
      <div class="find-list">
        <div class="find-item">
          <div class="find-icon"><i class="fa-solid fa-location-dot"></i></div>
          <div><strong><?php echo h(setting('address_line1')); ?></strong><span><?php echo h(setting('address_line2')); ?></span></div>
        </div>
        <div class="find-item">
          <div class="find-icon"><i class="fa-regular fa-clock"></i></div>
          <div><strong>Monday – Friday</strong><span>9:00 AM – 5:00 PM</span></div>
        </div>
        <div class="find-item">
          <div class="find-icon"><i class="fa-solid fa-car"></i></div>
          <div><strong>Parking on-site</strong><span>Free visitor parking available</span></div>
        </div>
      </div>
    </div>
    <div class="map-card">
      <div class="map-label"><strong>Helping Hands HQ</strong><span><?php echo h(setting('address_line1')); ?></span></div>
      <iframe title="Map showing Helping Hands office location" loading="lazy" src="https://www.google.com/maps?q=Cape+Town&output=embed"></iframe>
      <div class="map-actions">
        <a class="btn btn-orange" href="https://www.google.com/maps?q=Cape+Town" target="_blank" rel="noopener">Get Directions <i class="fa-solid fa-diamond-turn-right"></i></a>
      </div>
    </div>
  </div>
</section>

<section class="section" style="padding-top:0">
  <div class="container" style="max-width:1000px">
    <div class="section-title reveal">
      <span class="eyebrow">AFTER YOU SEND A MESSAGE</span>
      <h2>What happens next</h2>
    </div>
    <div class="steps">
      <div class="step">
        <div class="step-num">1</div>
        <h3>We receive your message</h3>
        <p>Your message reaches the right department automatically, based on the subject you choose.</p>
      </div>
      <div class="step">
        <div class="step-num">2</div>
        <h3>A real person reviews it</h3>
        <p>One of our community coordinators reads and responds — no bots, no auto-replies.</p>
      </div>
      <div class="step">
        <div class="step-num">3</div>
        <h3>You hear back within 24 hours</h3>
        <p>We reply by email, with next steps or an answer to your question.</p>
      </div>
    </div>
  </div>
</section>

<section class="section" style="background:#fff8ee">
  <div class="container">
    <div class="section-title reveal">
      <span class="eyebrow">STILL UNSURE?</span>
      <h2>Contact FAQ</h2>
    </div>
    <div class="faq-list">
      <div class="faq-item">
        <button class="faq-q" aria-expanded="false">How quickly will I get a reply? <i class="fa-solid fa-plus"></i></button>
        <div class="faq-a"><p>Most messages are answered within 24 hours on working days. Urgent safety concerns are prioritised — please call the helpline for anything time-sensitive.</p></div>
      </div>
      <div class="faq-item">
        <button class="faq-q" aria-expanded="false">Can I visit in person without an appointment? <i class="fa-solid fa-plus"></i></button>
        <div class="faq-a"><p>Yes, our office welcomes walk-ins during office hours. For longer discussions, emailing ahead helps us make sure the right person is available.</p></div>
      </div>
      <div class="faq-item">
        <button class="faq-q" aria-expanded="false">I want to report a safety concern — what do I do? <i class="fa-solid fa-plus"></i></button>
        <div class="faq-a"><p>Email <?php echo h(setting('email_trust')); ?> directly or select "Report a Concern" in the form above. Safeguarding messages are reviewed as a priority.</p></div>
      </div>
      <div class="faq-item">
        <button class="faq-q" aria-expanded="false">Do you offer support in languages other than English? <i class="fa-solid fa-plus"></i></button>
        <div class="faq-a"><p>Yes — our team can assist in English and Afrikaans, with isiXhosa support available on request.</p></div>
      </div>
    </div>
  </div>
</section>

</main>



<?php include __DIR__ . "/partials/footer.php"; ?>
</body>
</html>
