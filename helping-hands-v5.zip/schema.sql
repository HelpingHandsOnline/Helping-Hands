-- Helping Hands Community Assist
-- InfinityFree fresh-install database script
-- IMPORTANT: This script DROPS all Helping Hands tables before recreating them.
-- Use this for the first installation or when fixing an incomplete/failed import.
-- Do NOT run it on a live site if you need to keep existing data.

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS email_log;
DROP TABLE IF EXISTS ratings;
DROP TABLE IF EXISTS notifications;
DROP TABLE IF EXISTS password_resets;
DROP TABLE IF EXISTS contact_messages;
DROP TABLE IF EXISTS volunteers;
DROP TABLE IF EXISTS requests;
DROP TABLE IF EXISTS newsletter_subscribers;
DROP TABLE IF EXISTS users;
SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  first_name VARCHAR(80) NOT NULL,
  last_name VARCHAR(80) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  phone VARCHAR(40) NOT NULL,
  role ENUM('Requester','Volunteer','Both') NOT NULL DEFAULT 'Requester',
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS requests (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  volunteer_id INT UNSIGNED NULL,
  category VARCHAR(100) NOT NULL,
  location VARCHAR(255) NOT NULL,
  preferred_date DATE NOT NULL,
  preferred_time TIME NOT NULL,
  notes TEXT NULL,
  contact_method VARCHAR(40) NOT NULL DEFAULT 'Phone call',
  status ENUM('Pending','Accepted','Completed','Cancelled') NOT NULL DEFAULT 'Pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  accepted_at DATETIME NULL,
  completed_at DATETIME NULL,
  CONSTRAINT fk_request_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_request_volunteer FOREIGN KEY (volunteer_id) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_requests_status (status), INDEX idx_requests_user (user_id), INDEX idx_requests_volunteer (volunteer_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS volunteers (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL UNIQUE,
  areas VARCHAR(255) NOT NULL,
  availability VARCHAR(255) NOT NULL,
  skills TEXT NULL,
  emergency_contact_name VARCHAR(120) NOT NULL,
  emergency_contact_phone VARCHAR(40) NOT NULL,
  motivation TEXT NULL,
  status ENUM('Active','Paused') NOT NULL DEFAULT 'Active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_volunteer_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS contact_messages (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NULL,
  name VARCHAR(160) NOT NULL,
  email VARCHAR(190) NOT NULL,
  subject VARCHAR(160) NOT NULL,
  message TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  status ENUM('New','Read','Resolved') NOT NULL DEFAULT 'New',
  CONSTRAINT fk_message_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS newsletter_subscribers (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(190) NOT NULL UNIQUE,
  subscribed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ===== v5 additions (admin, verification, notifications, ratings, password reset, e-mail log) =====
ALTER TABLE users
  ADD COLUMN IF NOT EXISTS is_admin TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS notify_email TINYINT(1) NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS notify_sms TINYINT(1) NOT NULL DEFAULT 0;

ALTER TABLE requests
  ADD COLUMN IF NOT EXISTS updated_at DATETIME NULL,
  ADD COLUMN IF NOT EXISTS cancelled_at DATETIME NULL,
  ADD COLUMN IF NOT EXISTS cancel_reason VARCHAR(255) NULL;

ALTER TABLE volunteers
  ADD COLUMN IF NOT EXISTS verification_status ENUM('Unverified','Pending','Verified','Rejected') NOT NULL DEFAULT 'Unverified',
  ADD COLUMN IF NOT EXISTS id_document VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS ref1_name VARCHAR(120) NULL,
  ADD COLUMN IF NOT EXISTS ref1_phone VARCHAR(40) NULL,
  ADD COLUMN IF NOT EXISTS ref1_relationship VARCHAR(80) NULL,
  ADD COLUMN IF NOT EXISTS ref2_name VARCHAR(120) NULL,
  ADD COLUMN IF NOT EXISTS ref2_phone VARCHAR(40) NULL,
  ADD COLUMN IF NOT EXISTS ref2_relationship VARCHAR(80) NULL,
  ADD COLUMN IF NOT EXISTS verification_submitted_at DATETIME NULL,
  ADD COLUMN IF NOT EXISTS verification_note VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS verified_at DATETIME NULL,
  ADD COLUMN IF NOT EXISTS verified_by INT UNSIGNED NULL;

CREATE TABLE IF NOT EXISTS password_resets (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  token_hash CHAR(64) NOT NULL,
  expires_at DATETIME NOT NULL,
  used_at DATETIME NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_reset_token (token_hash),
  INDEX idx_reset_user (user_id),
  CONSTRAINT fk_reset_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS notifications (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  type VARCHAR(40) NOT NULL,
  title VARCHAR(160) NOT NULL,
  body TEXT NULL,
  link VARCHAR(190) NULL,
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_notif_user (user_id, is_read),
  CONSTRAINT fk_notif_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS ratings (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  request_id INT UNSIGNED NOT NULL UNIQUE,
  rater_id INT UNSIGNED NOT NULL,
  volunteer_id INT UNSIGNED NOT NULL,
  stars TINYINT UNSIGNED NOT NULL,
  comment VARCHAR(500) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_rating_volunteer (volunteer_id),
  CONSTRAINT fk_rating_request FOREIGN KEY (request_id) REFERENCES requests(id) ON DELETE CASCADE,
  CONSTRAINT fk_rating_rater FOREIGN KEY (rater_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_rating_volunteer FOREIGN KEY (volunteer_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS email_log (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NULL,
  channel ENUM('email','sms') NOT NULL DEFAULT 'email',
  to_address VARCHAR(190) NOT NULL,
  subject VARCHAR(250) NOT NULL,
  body TEXT NULL,
  status ENUM('sent','failed') NOT NULL,
  error_text VARCHAR(500) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_log_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------
-- MAKE YOURSELF AN ADMINISTRATOR (edit the e-mail, then run just this line):
-- UPDATE users SET is_admin = 1 WHERE email = 'your-account-email@example.com';
-- ---------------------------------------------------------------
