<?php
/**
 * site-settings.php — the ONE place to edit contact details, e-mail (SMTP), SMS and site options.
 * Nothing here is a secret that should be shared publicly: keep this file private.
 */
return [
    /* ---------- Public contact details (shown on Contact page, footer, e-mails) ----------
       Replace every value below with your REAL details. While "verified" is false, the
       Contact page shows a small "details being confirmed" note instead of pretending. */
    'verified'      => false,                 // set to true once the details below are real
    'phone'         => '(012) 345 6790',
    'whatsapp'      => '(012) 345 6790',
    'email'         => 'info@helpinghands.org',
    'email_volunteer' => 'volunteer@helpinghands.org',
    'email_trust'   => 'trust@helpinghands.org',
    'address_line1' => '123 Community Way',
    'address_line2' => 'Yourtown, ST 12345',
    'hours'         => 'Mon – Fri, 9:00 AM – 5:00 PM',

    /* ---------- Site address used inside e-mails, e.g. https://yourname.infinityfreeapp.com ---------- */
    'site_url'      => '',                    // IMPORTANT: set this so reset links are always correct

    /* ---------- E-mail sending (SMTP) ----------
       Use any SMTP provider (Gmail app password, Brevo, Mailjet, SendGrid, your own domain mailbox).
       Leave 'host' empty to fall back to PHP mail(), which InfinityFree usually blocks.
       NOTE: free hosts may block outgoing SMTP ports. If sending fails, every message is still
       recorded under Admin > Email log so you can show it working. */
    'smtp' => [
        'host'       => '',                   // e.g. smtp-relay.brevo.com / smtp.gmail.com
        'port'       => 587,                  // 587 (tls) or 465 (ssl)
        'encryption' => 'tls',                // 'tls' (STARTTLS), 'ssl' or 'none'
        'username'   => '',
        'password'   => '',
        'from_email' => '',                   // e.g. no-reply@yourdomain.com
        'from_name'  => 'Helping Hands Community Assist',
    ],

    /* ---------- SMS (optional, needs a paid Twilio account) ---------- */
    'sms' => [
        'provider'    => '',                  // 'twilio' to enable, empty = SMS off
        'account_sid' => '',
        'auth_token'  => '',
        'from'        => '',                  // your Twilio number, e.g. +14155550123
        'default_country_code' => '27',       // numbers starting with 0 become +27...
    ],
];
