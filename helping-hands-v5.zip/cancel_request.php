<?php
require 'config.php'; require_login();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect('tasks.php');
verify_csrf();
$id = post_id('id');
$me = user();

$pdo->beginTransaction();
$q = $pdo->prepare('SELECT * FROM requests WHERE id=? AND user_id=? FOR UPDATE');
$q->execute([$id, $me['id']]);
$req = $q->fetch();

if (!$req || !in_array($req['status'], ['Pending', 'Accepted'], true)) {
    $pdo->rollBack();
    flash('error', 'That request cannot be cancelled.');
    redirect('tasks.php');
}
$pdo->prepare("UPDATE requests SET status='Cancelled', cancelled_at=NOW(), updated_at=NOW() WHERE id=?")->execute([$id]);
$pdo->commit();

if ($req['status'] === 'Accepted' && $req['volunteer_id']) {
    notify((int)$req['volunteer_id'], 'cancelled', 'A task you accepted was cancelled',
        $me['first_name'] . ' cancelled the ' . $req['category'] . ' request for ' . $req['preferred_date'] . '. You do not need to do anything. Thank you for offering to help.', 'tasks.php');
}
flash('success', 'Your request has been cancelled.');
redirect('tasks.php');
