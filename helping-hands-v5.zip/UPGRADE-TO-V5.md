# Helping Hands v5 — upgrade guide (do these in order)

## 1. Update the database (2 minutes)
phpMyAdmin → your database → **Import** → choose `migration_v5.sql` → Go.
It only ADDS things (nothing is deleted) and is safe to run twice.
(Fresh install instead? Import `schema.sql`; it already includes everything.)

Then make yourself an administrator: phpMyAdmin → **SQL** tab →
`UPDATE users SET is_admin = 1 WHERE email = 'your-account-email@example.com';`

## 2. Upload the files
Upload everything in this zip to `htdocs` and overwrite. `config.php` is included with your existing
database details; it only gained one line at the bottom (`require_once __DIR__ . '/lib.php';`).
If you prefer to keep your own config.php, just add that same line at its very bottom.

## 3. Edit ONE file: `site-settings.php`
- Real phone, e-mail, address, hours, then set `'verified' => true`.
- `'site_url'` = your site address (e.g. https://yourname.infinityfreeapp.com). Needed for correct e-mail links.
- `smtp` = your e-mail provider's details (Brevo, Gmail app password, Mailjet, your domain mailbox...).
- `sms` = optional, Twilio only.

## 3b. Social media icons
Paste your real page addresses into `social-links.php`. An icon only appears when it has an address (no dead buttons).
WhatsApp links itself from the phone number in site-settings.php once `verified` is true.

## 4. Real photos
Drop your own photos into `images/photos/` using these names (.jpg/.png/.webp) and they replace the stock photos automatically:
about-1, about-2, contact-1, volunteer-1, resources-1 ... resources-12.
(Homepage slideshow photos still use images/hero-1.jpg ... hero-4.jpg as before.)

## 5. Test checklist
1. Log out → Forgot password → check Admin → "Email & SMS log" (shows sent/failed even if SMTP is blocked).
2. Volunteer: apply → verify.php (upload ID + 2 references) → Admin → Verification → Approve.
3. Requester: make a request → Edit it → Cancel it → make another.
4. Volunteer: Task Centre → search by area/category/date → Accept → requester sees a notification (bell).
5. Volunteer: Mark completed → requester: Rate volunteer.
6. Switch language (EN / AF / XH) in the header; install as an app on a phone (needs https).

## Things to know
- Existing volunteers become "Unverified" and must verify before accepting tasks (that is the point of the safety feature).
- InfinityFree may block outgoing SMTP/PHP mail(). If so, the e-mail log proves the feature works; use a host that allows SMTP, or an API-based mail service, for real delivery.
- Translations cover the navigation, header, footer and notification screens (English, Afrikaans, isiXhosa). Long page text is still English. Please have a first-language speaker check the Afrikaans and isiXhosa wording.
- ID documents are stored privately in `uploads/ids/` and deleted automatically when an admin approves or rejects.
