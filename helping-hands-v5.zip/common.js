/* ==========================================================================
   HELPING HANDS — COMMON SCRIPT (loaded with `defer` from the footer)
   Mobile nav, FAQ accordion, password toggle, scroll reveal, back-to-top.
   Every block checks that its elements exist, so no page can break it.
   ========================================================================== */
(function () {
  "use strict";
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

  /* Mobile navigation */
  var menuBtn = $("#menuBtn"), nav = $("#nav");
  if (menuBtn && nav) {
    var setMenu = function (open) {
      nav.classList.toggle("open", open);
      menuBtn.setAttribute("aria-expanded", open ? "true" : "false");
      menuBtn.setAttribute("aria-label", open ? "Close menu" : "Open menu");
      menuBtn.innerHTML = '<i class="fa-solid ' + (open ? "fa-xmark" : "fa-bars") + '" aria-hidden="true"></i>';
    };
    menuBtn.addEventListener("click", function () { setMenu(!nav.classList.contains("open")); });
    $$("a", nav).forEach(function (a) { a.addEventListener("click", function () { setMenu(false); }); });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && nav.classList.contains("open")) { setMenu(false); menuBtn.focus(); }
    });
    window.addEventListener("resize", function () { if (window.innerWidth > 1020) setMenu(false); });
  }

  /* FAQ accordion */
  $$(".faq-item").forEach(function (item, i) {
    var q = $(".faq-q", item), a = $(".faq-a", item);
    if (!q) return;
    if (a) {
      a.id = a.id || "faq-a-" + i;
      q.setAttribute("aria-controls", a.id);
      a.setAttribute("role", "region");
    }
    q.setAttribute("aria-expanded", item.classList.contains("open") ? "true" : "false");
    q.addEventListener("click", function () {
      var wasOpen = item.classList.contains("open");
      var list = item.closest(".faq-list");
      if (list) $$(".faq-item", list).forEach(function (o) {
        o.classList.remove("open");
        var oq = $(".faq-q", o); if (oq) oq.setAttribute("aria-expanded", "false");
      });
      if (!wasOpen) { item.classList.add("open"); q.setAttribute("aria-expanded", "true"); }
    });
  });

  /* Password show/hide (login + signup) */
  $$(".reveal-toggle").forEach(function (btn) {
    btn.setAttribute("aria-label", "Show password");
    var tgt = document.getElementById(btn.dataset.target); if (tgt) tgt.classList.add("has-toggle");
    btn.addEventListener("click", function () {
      var input = document.getElementById(btn.dataset.target);
      if (!input) return;
      var showing = input.type === "text";
      input.type = showing ? "password" : "text";
      btn.setAttribute("aria-label", showing ? "Show password" : "Hide password");
      var icon = $("i", btn);
      if (icon) icon.className = showing ? "fa-regular fa-eye" : "fa-regular fa-eye-slash";
    });
  });

  /* Scroll reveal (CSS only hides .reveal when JS is running) */
  var reveals = $$(".reveal, .reveal-left, .reveal-right, .reveal-zoom");
  if ("IntersectionObserver" in window && reveals.length) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) { e.target.classList.add("in-view"); io.unobserve(e.target); }
      });
    }, { threshold: 0.12 });
    reveals.forEach(function (el) { io.observe(el); });
  } else {
    reveals.forEach(function (el) { el.classList.add("in-view"); });
  }

  /* Hero slideshow */
  var slider = $("#heroSlider");
  if (slider) {
    var slides = $$(".hs-slide", slider), dots = $$(".hs-dot", slider), idx = 0, timer = null, paused = false;
    var reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    var show = function (n) {
      idx = (n + slides.length) % slides.length;
      slides.forEach(function (s, i) {
        var on = i === idx;
        s.classList.toggle("is-active", on);
        s.setAttribute("aria-hidden", on ? "false" : "true");
        $$("a,button", s).forEach(function (el) { el.tabIndex = on ? 0 : -1; });
      });
      dots.forEach(function (d, i) { d.classList.toggle("is-active", i === idx); });
      /* optional hero videos: only the visible slide plays; skipped on data-saver or reduced motion */
      var canVideo = !reduce && !(navigator.connection && navigator.connection.saveData);
      slides.forEach(function (s, i) {
        var v = $("video.hs-video", s);
        if (!v) return;
        if (i === idx && canVideo) { var p = v.play(); if (p && p.catch) p.catch(function () {}); } else { v.pause(); }
      });
    };
    var stop = function () { if (timer) { clearInterval(timer); timer = null; } };
    var start = function () { stop(); if (!paused && !reduce) timer = setInterval(function () { show(idx + 1); }, 7000); };
    var nextBtn = $("#hsNext"), prevBtn = $("#hsPrev");
    if (nextBtn) nextBtn.addEventListener("click", function () { show(idx + 1); start(); });
    if (prevBtn) prevBtn.addEventListener("click", function () { show(idx - 1); start(); });
    dots.forEach(function (d) { d.addEventListener("click", function () { show(parseInt(d.dataset.i, 10)); start(); }); });
    var pauseBtn = $("#hsPause");
    if (pauseBtn) pauseBtn.addEventListener("click", function () {
      paused = !paused;
      pauseBtn.setAttribute("aria-label", paused ? "Play slideshow" : "Pause slideshow");
      pauseBtn.innerHTML = '<i class="fa-solid ' + (paused ? "fa-play" : "fa-pause") + '" aria-hidden="true"></i>';
      paused ? stop() : start();
    });
    slider.addEventListener("mouseenter", stop);
    slider.addEventListener("mouseleave", function () { if (!paused) start(); });
    slider.addEventListener("focusin", stop);
    slider.addEventListener("keydown", function (e) {
      if (e.key === "ArrowRight") { show(idx + 1); start(); } else if (e.key === "ArrowLeft") { show(idx - 1); start(); }
    });
    show(0); start();
  }

  /* Count-up for live stats */
  $$("[data-count]").forEach(function (el) {
    var target = parseInt(el.dataset.count, 10);
    if (!target || (window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches) || !("IntersectionObserver" in window)) return;
    el.textContent = "0";
    new IntersectionObserver(function (en, ob) {
      if (!en[0].isIntersecting) return; ob.disconnect();
      var t0 = null; var step = function (t) { if (!t0) t0 = t; var p = Math.min((t - t0) / 1200, 1); el.textContent = Math.round(target * p); if (p < 1) requestAnimationFrame(step); };
      requestAnimationFrame(step);
    }, { threshold: .4 }).observe(el);
  });

  /* Header: hides while scrolling down, returns when scrolling up */
  var header = $("#siteHeader");
  if (header) {
    var lastY = window.scrollY, ticking = false;
    var update = function () {
      var y = window.scrollY, menuOpen = nav && nav.classList.contains("open");
      header.classList.toggle("is-scrolled", y > 10);
      if (menuOpen || y < 120 || header.contains(document.activeElement)) header.classList.remove("header-hidden");
      else if (y > lastY + 6) header.classList.add("header-hidden");
      else if (y < lastY - 6) header.classList.remove("header-hidden");
      lastY = y; ticking = false;
    };
    window.addEventListener("scroll", function () { if (!ticking) { ticking = true; window.requestAnimationFrame(update); } }, { passive: true });
    header.addEventListener("focusin", function () { header.classList.remove("header-hidden"); });
    update();
  }
  var footTop = $("#footTop");
  if (footTop) footTop.addEventListener("click", function (e) { e.preventDefault(); window.scrollTo({ top: 0 }); });

  /* Back to top */
  var toTop = $("#toTop");
  if (toTop) {
    var onScroll = function () { toTop.classList.toggle("show", window.scrollY > 700); };
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    toTop.addEventListener("click", function () { window.scrollTo({ top: 0 }); });
  }

  /* Progressive web app: register the service worker + "Install app" button */
  if ("serviceWorker" in navigator && (location.protocol === "https:" || location.hostname === "localhost")) {
    window.addEventListener("load", function () { navigator.serviceWorker.register("sw.js").catch(function () {}); });
  }
  var deferredInstall = null, installBtns = $$(".install-btn");
  window.addEventListener("beforeinstallprompt", function (e) {
    e.preventDefault(); deferredInstall = e;
    installBtns.forEach(function (x) { x.hidden = false; });
  });
  installBtns.forEach(function (x) {
    x.addEventListener("click", function () {
      if (!deferredInstall) return;
      deferredInstall.prompt();
      deferredInstall.userChoice.then(function () { deferredInstall = null; installBtns.forEach(function (y) { y.hidden = true; }); });
    });
  });
  window.addEventListener("appinstalled", function () { installBtns.forEach(function (x) { x.hidden = true; }); });

  /* Confirm dialogs for destructive buttons: <form data-confirm="Are you sure?"> */
  $$("form[data-confirm]").forEach(function (f) {
    f.addEventListener("submit", function (e) { if (!window.confirm(f.dataset.confirm)) e.preventDefault(); });
  });
})();
